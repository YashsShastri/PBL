import face_recognition
import cv2
import os
import sys
import json

# Directory where student face images are stored
FACE_DIR = "python/faces/"

def recognize_face(input_image_path):
    try:
        # Load the input image
        input_image = face_recognition.load_image_file(input_image_path)
        input_encodings = face_recognition.face_encodings(input_image)
        
        if not input_encodings:
            return json.dumps({"status": "error", "message": "No face detected in the input image"})
        
        input_encoding = input_encodings[0]
        known_faces = []
        known_names = []

        # Load known faces from FACE_DIR
        for filename in os.listdir(FACE_DIR):
            if filename.endswith(".jpg") or filename.endswith(".png"):
                known_image = face_recognition.load_image_file(os.path.join(FACE_DIR, filename))
                encodings = face_recognition.face_encodings(known_image)
                if encodings:
                    known_faces.append(encodings[0])
                    known_names.append(os.path.splitext(filename)[0])

        # Compare faces
        results = face_recognition.compare_faces(known_faces, input_encoding, tolerance=0.6)
        distances = face_recognition.face_distance(known_faces, input_encoding)
        
        if True in results:
            best_match_index = results.index(True)
            name = known_names[best_match_index]
            confidence = 1 - distances[best_match_index]
            return json.dumps({"status": "success", "name": name, "confidence": float(confidence)})
        else:
            return json.dumps({"status": "unknown", "message": "No match found"})
    
    except Exception as e:
        return json.dumps({"status": "error", "message": str(e)})

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(json.dumps({"status": "error", "message": "Usage: python face_recognition.py <image_path>"}))
        sys.exit(1)
    
    image_path = sys.argv[1]
    result = recognize_face(image_path)
    print(result)