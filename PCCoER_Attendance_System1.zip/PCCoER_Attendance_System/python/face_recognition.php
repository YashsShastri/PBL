<?php
require_once 'config.php';
require_once 'functions.php';

header('Content-Type: application/json');
redirectIfNotLoggedIn();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    $image = $_FILES['image'];
    $temp_path = 'python/temp_' . time() . '.jpg';
    
    if (move_uploaded_file($image['tmp_name'], $temp_path)) {
        $command = escapeshellcmd("python face_recognition.py " . escapeshellarg($temp_path));
        $output = shell_exec($command);
        unlink($temp_path); // Clean up
        echo $output; // JSON response from Python
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to upload image"]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request"]);
}
exit;