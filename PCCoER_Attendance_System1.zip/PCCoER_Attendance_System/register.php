<?php
require_once 'config.php';
require_once 'functions.php';

redirectIfNotLoggedIn();
if (!$_SESSION['first_login']) {
    header("Location: {$_SESSION['role']}_dashboard.php");
    exit;
}

$role = getUserRole();
$error = $message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($role === 'Student') {
        $prn = trim($_POST['prn']);
        $roll_no = trim($_POST['roll_no']);
        $division_id = (int)$_POST['division_id'];
        $face_image = $_FILES['face_image'];

        if (empty($prn) || empty($roll_no) || !$division_id || !$face_image['name']) {
            $error = "All fields are required.";
        } elseif ($face_image['error'] !== UPLOAD_ERR_OK || !in_array($face_image['type'], ['image/jpeg', 'image/png'])) {
            $error = "Please upload a valid JPEG or PNG image.";
        } else {
            $year = date('Y');
            $stmt = $conn->prepare("SELECT d.name FROM departments_db d JOIN division_db div ON d.id = div.department_id WHERE div.id = :division_id");
            $stmt->execute(['division_id' => $division_id]);
            $dept = strtoupper(substr($stmt->fetchColumn(), 0, 4));
            $filename = "SE{$dept}{$roll_no}_{$year}_{$prn}.jpg";
            $uploadPath = UPLOAD_DIR . $filename;

            if (move_uploaded_file($face_image['tmp_name'], $uploadPath)) {
                $stmt = $conn->prepare("INSERT INTO students_db (user_id, division_id, prn, roll_no, face_image) VALUES (:user_id, :division_id, :prn, :roll_no, :face_image)");
                $stmt->execute([
                    'user_id' => $_SESSION['user_id'],
                    'division_id' => $division_id,
                    'prn' => $prn,
                    'roll_no' => $roll_no,
                    'face_image' => $uploadPath
                ]);
                $conn->prepare("UPDATE users_db SET first_login = FALSE WHERE id = :id")->execute(['id' => $_SESSION['user_id']]);
                $_SESSION['first_login'] = false;
                logAction($_SESSION['user_id'], "Completed student registration");
                header('Location: student_dashboard.php');
                exit;
            } else {
                $error = "Failed to upload face image.";
            }
        }
    } elseif ($role === 'Teacher') {
        $department_id = (int)$_POST['department_id'];
        $division_id = isset($_POST['division_id']) ? (int)$_POST['division_id'] : null;

        if (!$department_id) {
            $error = "Department is required.";
        } else {
            $stmt = $conn->prepare("UPDATE users_db SET first_login = FALSE, department_id = :department_id, division_id = :division_id WHERE id = :id");
            $stmt->execute([
                'department_id' => $department_id,
                'division_id' => $division_id,
                'id' => $_SESSION['user_id']
            ]);
            $_SESSION['first_login'] = false;
            logAction($_SESSION['user_id'], "Completed teacher registration");
            header('Location: teacher_dashboard.php');
            exit;
        }
    } else { // Admin
        $conn->prepare("UPDATE users_db SET first_login = FALSE WHERE id = :id")->execute(['id' => $_SESSION['user_id']]);
        $_SESSION['first_login'] = false;
        logAction($_SESSION['user_id'], "Completed admin registration");
        header('Location: admin_dashboard.php');
        exit;
    }
}

$departments = $conn->query("SELECT id, name FROM departments_db")->fetchAll(PDO::FETCH_ASSOC);
$divisions = $conn->query("SELECT id, name, department_id FROM division_db")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Register - PCCoER Attendance System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background: #f5f7fa; color: #1e2a44; min-height: 100vh; display: flex; justify-content: center; align-items: center; }
        .register-container { background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.1); width: 90%; max-width: 500px; }
        h2 { font-size: 24px; font-weight: 600; margin-bottom: 15px; text-align: center; position: relative; }
        h2::after { content: ''; position: absolute; bottom: -5px; left: 50%; transform: translateX(-50%); width: 30px; height: 3px; background: #4b5e82; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-weight: 500; margin-bottom: 5px; font-size: 14px; }
        .form-group input, .form-group select { width: 100%; padding: 10px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; }
        .form-group input:focus, .form-group select:focus { border-color: #4b5e82; outline: none; }
        .btn { width: 100%; padding: 10px; border: none; border-radius: 8px; background: #4b5e82; color: #fff; font-size: 14px; cursor: pointer; transition: all .3s ease; }
        .btn:hover { background: #3b4a6b; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,.1); }
        .error { color: #e63946; text-align: center; margin-top: 10px; font-size: 12px; }
        .message { color: #2d6a4f; text-align: center; margin-top: 10px; font-size: 12px; }
        footer { position: absolute; bottom: 10px; text-align: center; color: #4b5e82; font-size: 12px; width: 100%; }
        footer a { color: #4b5e82; text-decoration: none; }
        @media (max-width: 480px) {
            .register-container { padding: 20px; }
            h2 { font-size: 20px; }
            .form-group label { font-size: 12px; }
            .form-group input, .form-group select, .btn { font-size: 12px; padding: 8px; }
            .error, .message { font-size: 10px; }
            footer { font-size: 10px; }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>Complete Your Registration</h2>
        <form method="POST" enctype="multipart/form-data">
            <?php if ($role === 'Student'): ?>
                <div class="form-group">
                    <label for="prn">PRN</label>
                    <input type="text" id="prn" name="prn" required>
                </div>
                <div class="form-group">
                    <label for="roll_no">Roll Number</label>
                    <input type="text" id="roll_no" name="roll_no" required>
                </div>
                <div class="form-group">
                    <label for="division_id">Division</label>
                    <select id="division_id" name="division_id" required>
                        <option value="">Select Division</option>
                        <?php foreach ($divisions as $div): ?>
                            <option value="<?php echo $div['id']; ?>"><?php echo htmlspecialchars($div['name']); ?> (<?php echo $departments[array_search($div['department_id'], array_column($departments, 'id'))]['name']; ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="face_image">Face Image (JPEG/PNG)</label>
                    <input type="file" id="face_image" name="face_image" accept="image/jpeg,image/png" required>
                </div>
            <?php elseif ($role === 'Teacher'): ?>
                <div class="form-group">
                    <label for="department_id">Department</label>
                    <select id="department_id" name="department_id" required>
                        <option value="">Select Department</option>
                        <?php foreach ($departments as $dept): ?>
                            <option value="<?php echo $dept['id']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="division_id">Division (Optional)</label>
                    <select id="division_id" name="division_id">
                        <option value="">None</option>
                        <?php foreach ($divisions as $div): ?>
                            <option value="<?php echo $div['id']; ?>"><?php echo htmlspecialchars($div['name']); ?> (<?php echo $departments[array_search($div['department_id'], array_column($departments, 'id'))]['name']; ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
            <?php endif; ?>
            <button type="submit" class="btn">Register</button>
        </form>
        <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
        <?php if ($message): ?><p class="message"><?php echo htmlspecialchars($message); ?></p><?php endif; ?>
    </div>
    <footer>
        <p>© PCCoER Attendance System | <a href="help.php">Need Help?</a></p>
    </footer>
</body>
</html>