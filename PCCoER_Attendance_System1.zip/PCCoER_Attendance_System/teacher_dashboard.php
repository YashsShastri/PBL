<?php
require_once 'config.php';
require_once 'functions.php';
require_once 'phpqrcode/qrlib.php'; // For QR code generation

redirectIfNotLoggedIn();
$user_id = $_SESSION['user_id'];
$role = getUserRole();
if (!in_array($role, ['Regular Teacher', 'Class Teacher'])) {
    header('Location: index.php');
    exit;
}

// Check if first-time login
$is_first_login = $_SESSION['first_login'] ?? false;

// Fetch teacher's details
$stmt = $conn->prepare("SELECT email, name, department_id, first_login FROM users_db WHERE id = :id");
$stmt->execute(['id' => $user_id]);
$teacher = $stmt->fetch(PDO::FETCH_ASSOC);
$dept_id = $teacher['department_id'];

// Fetch division if Class Teacher
$division_id = null;
if ($role === 'Class Teacher') {
    $stmt = $conn->prepare("SELECT division_id FROM class_teachers_db WHERE user_id = :user_id");
    $stmt->execute(['user_id' => $user_id]);
    $division_id = $stmt->fetchColumn();
}

// Handle form submissions
$error = $message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['register_teacher'])) {
            $email = trim($_POST['email']);
            $dept = $_POST['department'];
            $role = $_POST['role'];
            $division = $role === 'Class Teacher' ? trim($_POST['division']) : null;
            if (!preg_match('/^[a-z]+\.[a-z]+@pccoer\.in$/', $email)) {
                throw new Exception("Invalid email format. Use name.surname@pccoer.in");
            }
            $stmt = $conn->prepare("UPDATE users_db SET email = :email, department_id = (SELECT id FROM departments_db WHERE name = :dept), role = :role, first_login = FALSE WHERE id = :id");
            $stmt->execute(['email' => $email, 'dept' => $dept, 'role' => $role, 'id' => $user_id]);
            if ($role === 'Class Teacher') {
                $stmt = $conn->prepare("INSERT INTO class_teachers_db (user_id, division_id) VALUES (:user_id, (SELECT id FROM division_db WHERE name = :division AND department_id = (SELECT id FROM departments_db WHERE name = :dept)))");
                $stmt->execute(['user_id' => $user_id, 'division' => $division, 'dept' => $dept]);
                $division_id = $conn->lastInsertId();
            }
            $_SESSION['first_login'] = false;
            $is_first_login = false;
            $message = "Registration completed successfully.";
            logAction($user_id, "Completed first-time registration as $role");
        } elseif (isset($_POST['manual_attendance'])) {
            $prn = trim($_POST['prn']);
            $status = $_POST['status'];
            $stmt = $conn->prepare("SELECT id FROM students_db WHERE prn = :prn" . ($division_id ? " AND division_id = :division_id" : ""));
            $params = ['prn' => $prn];
            if ($division_id) $params['division_id'] = $division_id;
            $stmt->execute($params);
            $student_id = $stmt->fetchColumn();
            if ($student_id) {
                $stmt = $conn->prepare("INSERT INTO attendance_db (student_id, date, status, method, teacher_id) VALUES (:student_id, NOW(), :status, 'Manual', :teacher_id) ON DUPLICATE KEY UPDATE status = :status");
                $stmt->execute(['student_id' => $student_id, 'status' => $status, 'teacher_id' => $user_id]);
                logAction($user_id, "Marked manual attendance for PRN: $prn");
                $message = "Attendance marked successfully.";
            } else {
                $error = "Student not found.";
            }
        } elseif (isset($_POST['update_student']) && $role === 'Class Teacher') {
            $prn = trim($_POST['prn']);
            $name = trim($_POST['name']);
            $roll_no = trim($_POST['roll_no']);
            $division = trim($_POST['division']);
            $stmt = $conn->prepare("UPDATE students_db s JOIN users_db u ON s.user_id = u.id SET u.name = :name, s.roll_no = :roll_no, s.division_id = (SELECT id FROM division_db WHERE name = :division AND department_id = :dept_id) WHERE s.prn = :prn AND s.division_id = :division_id");
            $stmt->execute(['name' => $name, 'roll_no' => $roll_no, 'division' => $division, 'dept_id' => $dept_id, 'prn' => $prn, 'division_id' => $division_id]);
            logAction($user_id, "Updated student PRN: $prn");
            $message = "Student updated successfully.";
        } elseif (isset($_POST['send_notification'])) {
            $msg = trim($_POST['message']);
            $stmt = $conn->prepare("INSERT INTO notification_db (message, user_id) VALUES (:message, :user_id)");
            $stmt->execute(['message' => $msg, 'user_id' => $user_id]);
            logAction($user_id, "Sent notification: $msg");
            $message = "Notification sent successfully.";
        } elseif (isset($_POST['reply_doubt']) && $role === 'Class Teacher') {
            $doubt_id = (int)$_POST['doubt_id'];
            $reply = trim($_POST['reply']);
            $stmt = $conn->prepare("UPDATE doubts_db SET reply = :reply, replied_at = NOW() WHERE id = :id AND division_id = :division_id");
            $stmt->execute(['reply' => $reply, 'id' => $doubt_id, 'division_id' => $division_id]);
            logAction($user_id, "Replied to doubt ID: $doubt_id");
            $message = "Reply sent successfully.";
        } elseif (isset($_POST['update_timetable']) && $role === 'Class Teacher') {
            $day = trim($_POST['day']);
            $time = trim($_POST['time']);
            $class = trim($_POST['class']);
            $room = trim($_POST['room']);
            $stmt = $conn->prepare("INSERT INTO timetable_db (division_id, day, time, class, room) VALUES (:division_id, :day, :time, :class, :room) ON DUPLICATE KEY UPDATE class = :class, room = :room");
            $stmt->execute(['division_id' => $division_id, 'day' => $day, 'time' => $time, 'class' => $class, 'room' => $room]);
            logAction($user_id, "Updated timetable for $day at $time");
            $message = "Timetable updated successfully.";
        }
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Fetch data based on role
$students = $attendance = $notifications = $schedule = $doubts = $timetable = [];
if (!$is_first_login) {
    $student_query = "SELECT s.id, u.name, s.prn, s.roll_no, div.name AS division, (SELECT COUNT(*) FROM attendance_db a WHERE a.student_id = s.id AND a.status = 'Present') / (SELECT COUNT(*) FROM attendance_db a WHERE a.student_id = s.id) * 100 AS attendance FROM students_db s JOIN users_db u ON s.user_id = u.id JOIN division_db div ON s.division_id = div.id";
    if ($division_id) $student_query .= " WHERE s.division_id = :division_id";
    $stmt = $conn->prepare($student_query);
    if ($division_id) $stmt->execute(['division_id' => $division_id]);
    else $stmt->execute();
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $attendance_query = "SELECT a.date, s.prn, a.status, a.method FROM attendance_db a JOIN students_db s ON a.student_id = s.id";
    if ($division_id) $attendance_query .= " WHERE s.division_id = :division_id";
    $attendance_query .= " ORDER BY a.date DESC LIMIT 50";
    $stmt = $conn->prepare($attendance_query);
    if ($division_id) $stmt->execute(['division_id' => $division_id]);
    else $stmt->execute();
    $attendance = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $notifications = $conn->query("SELECT message, created_at FROM notification_db WHERE user_id = $user_id ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

    $schedule_query = "SELECT date, time, class, room FROM schedule_db";
    if ($division_id) $schedule_query .= " WHERE division_id = :division_id";
    $schedule_query .= " ORDER BY date, time";
    $stmt = $conn->prepare($schedule_query);
    if ($division_id) $stmt->execute(['division_id' => $division_id]);
    else $stmt->execute();
    $schedule = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($role === 'Class Teacher') {
        $doubts = $conn->prepare("SELECT d.id, u.name AS student, d.query, d.created_at FROM doubts_db d JOIN users_db u ON d.student_id = u.id WHERE d.division_id = :division_id AND d.reply IS NULL ORDER BY d.created_at DESC");
        $doubts->execute(['division_id' => $division_id]);
        $doubts = $doubts->fetchAll(PDO::FETCH_ASSOC);

        $timetable = $conn->prepare("SELECT day, time, class, room FROM timetable_db WHERE division_id = :division_id ORDER BY FIELD(day, 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'), time");
        $timetable->execute(['division_id' => $division_id]);
        $timetable = $timetable->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Generate QR code if requested
$qr_file = null;
if (isset($_GET['generate_qr'])) {
    $qr_data = json_encode(['teacher_id' => $user_id, 'division_id' => $division_id, 'timestamp' => time()]);
    $qr_file = 'temp/qr_' . $user_id . '.png';
    QRcode::png($qr_data, $qr_file, QR_ECLEVEL_L, 5);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PCCoER Teacher Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background-color: #f5f7fa; color: #1e2a44; line-height: 1.6; overflow-x: hidden; }
        .sidebar { position: fixed; top: 0; left: 0; width: 270px; height: 100%; background: linear-gradient(180deg, #1e2a44 0%, #172038 100%); color: #d1d5db; padding: 20px; transition: transform .3s ease; box-shadow: 2px 0 15px rgba(0,0,0,.05); z-index: 1000; }
        .sidebar.hidden { transform: translateX(-270px); }
        .sidebar .logo { font-size: 22px; font-weight: 600; margin-bottom: 30px; text-align: center; color: #fff; }
        .sidebar ul { list-style: none; }
        .sidebar ul li { margin: 15px 0; }
        .sidebar ul li a { color: #d1d5db; text-decoration: none; font-size: 14px; font-weight: 400; display: flex; align-items: center; padding: 10px 15px; border-radius: 8px; transition: all .3s ease; }
        .sidebar ul li a.active, .sidebar ul li a:hover { background-color: #3b4a6b; color: #fff; }
        .sidebar ul li a i { margin-right: 10px; font-size: 16px; }
        .top-bar { position: fixed; top: 0; left: 270px; width: calc(100% - 270px); background: #fff; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,.05); transition: left .3s ease, width .3s ease; z-index: 999; }
        .top-bar.full-width { left: 0; width: 100%; }
        .top-bar .user-info { display: flex; align-items: center; gap: 10px; }
        .top-bar .user-info span { font-weight: 500; font-size: 14px; }
        .top-bar .controls { display: flex; align-items: center; gap: 15px; }
        .top-bar .hamburger { font-size: 20px; cursor: pointer; color: #4b5e82; }
        .top-bar .notifications { position: relative; }
        .top-bar .notifications i { font-size: 18px; cursor: pointer; color: #4b5e82; }
        .top-bar .notifications .badge { position: absolute; top: -5px; right: -5px; background-color: #e63946; color: #fff; font-size: 10px; padding: 2px 5px; border-radius: 50%; }
        .push-notification { position: fixed; top: 50px; right: 10px; padding: 8px 15px; border-radius: 8px; color: #fff; font-size: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.15); display: none; z-index: 1001; animation: slideInDown .5s ease forwards; }
        @keyframes slideInDown { from { transform: translateY(-100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .push-notification.important { background: #e63946; }
        .push-notification.normal { background: #2d6a4f; }
        .push-notification.medium { background: #f4a261; color: #1e2a44; }
        .main-content { margin-left: 270px; margin-top: 60px; padding: 20px; min-height: calc(100vh - 100px); transition: margin-left .3s ease; }
        .main-content.full-width { margin-left: 0; }
        .section { display: none; background: #fff; padding: 20px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.05); margin-bottom: 20px; }
        .section.active { display: block; }
        h2 { font-size: 20px; font-weight: 600; margin-bottom: 15px; position: relative; }
        h2::after { content: ''; position: absolute; bottom: -5px; left: 0; width: 30px; height: 2px; background: #4b5e82; }
        .card-container { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 20px; }
        .card { background: #fff; padding: 20px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.05); text-align: center; border-left: 4px solid #4b5e82; cursor: pointer; transition: transform .3s ease; }
        .card:hover { transform: translateY(-5px); }
        .card h3 { font-size: 16px; font-weight: 500; margin-bottom: 10px; }
        .card p { font-size: 24px; font-weight: 600; color: #4b5e82; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-weight: 500; margin-bottom: 5px; font-size: 14px; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; }
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; background: #fff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.05); }
        table th, table td { padding: 10px; text-align: left; font-size: 12px; }
        table th { background: #4b5e82; color: #fff; font-weight: 500; }
        table tr { transition: background .3s ease; }
        table tr:hover { background: #f9fafb; }
        table td { border-bottom: 1px solid #e5e7eb; }
        .btn { padding: 10px 15px; border: none; border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 500; transition: all .3s ease; display: inline-flex; align-items: center; gap: 5px; }
        .btn-primary { background: #4b5e82; color: #fff; }
        .btn-primary:hover { background: #3b4a6b; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,.1); }
        .btn-danger { background: #e63946; color: #fff; }
        .btn-danger:hover { background: #c53030; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,.1); }
        .btn i { font-size: 14px; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,.7); justify-content: center; align-items: center; z-index: 1000; }
        .modal-content { background: #fff; padding: 20px; border-radius: 12px; width: 90%; max-width: 500px; box-shadow: 0 6px 25px rgba(0,0,0,.15); }
        .error { color: #e63946; text-align: center; margin-bottom: 10px; font-size: 12px; }
        .message { color: #2d6a4f; text-align: center; margin-bottom: 10px; font-size: 12px; }
        footer { position: fixed; bottom: 0; left: 270px; width: calc(100% - 270px); background: #1e2a44; color: #d1d5db; padding: 10px 20px; text-align: center; font-size: 12px; transition: left .3s ease, width .3s ease; z-index: 998; }
        footer.full-width { left: 0; width: 100%; }
        footer span { margin: 0 5px; }
        @media (max-width: 768px) {
            .sidebar { width: 220px; }
            .main-content { margin-left: 220px; }
            .top-bar { left: 220px; width: calc(100% - 220px); }
            footer { left: 220px; width: calc(100% - 220px); }
        }
        @media (max-width: 480px) {
            .sidebar { width: 100%; height: auto; position: relative; transform: translateX(-100%); padding: 10px; }
            .sidebar.hidden { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .top-bar { left: 0; width: 100%; padding: 10px; }
            .top-bar .user-info span { font-size: 12px; }
            .top-bar .hamburger { font-size: 18px; }
            .main-content { margin-left: 0; margin-top: 50px; padding: 10px; }
            h2 { font-size: 18px; }
            .card h3 { font-size: 14px; }
            .card p { font-size: 20px; }
            .form-group label { font-size: 12px; }
            .form-group input, .form-group select, .form-group textarea { font-size: 12px; padding: 8px; }
            .btn { font-size: 10px; padding: 8px 12px; }
            table th, table td { font-size: 10px; padding: 8px; }
            footer { font-size: 10px; padding: 8px; }
        }
    </style>
</head>
<body>
    <div class="top-bar">
        <div class="user-info">
            <i class="fas fa-bars hamburger" onclick="toggleSidebar()"></i>
            <span><?php echo htmlspecialchars($teacher['name'] ?? 'Teacher'); ?></span>
        </div>
        <div class="controls">
            <div class="notifications">
                <i class="fas fa-bell" onclick="showPushNotification('notifications')"></i>
                <span class="badge"><?php echo count($notifications); ?></span>
                <?php foreach ($notifications as $i => $notif): ?>
                    <div class="push-notification <?php echo ['important', 'normal', 'medium'][$i % 3]; ?>" id="push-<?php echo $i; ?>"><?php echo htmlspecialchars($notif['message']); ?></div>
                <?php endforeach; ?>
            </div>
            <a href="logout.php" class="btn btn-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>

    <div class="sidebar hidden">
        <div class="logo">PCCoER Teacher</div>
        <ul>
            <li><a href="#attendance" class="active"><i class="fas fa-calendar-check"></i> Attendance</a></li>
            <?php if ($role === 'Class Teacher'): ?>
                <li><a href="#students"><i class="fas fa-user-graduate"></i> Students</a></li>
            <?php endif; ?>
            <li><a href="#notifications"><i class="fas fa-bell"></i> Notifications</a></li>
            <li><a href="#schedule"><i class="fas fa-clock"></i> Schedule</a></li>
            <?php if ($role === 'Class Teacher'): ?>
                <li><a href="#doubts"><i class="fas fa-question-circle"></i> Doubts</a></li>
                <li><a href="#timetable"><i class="fas fa-table"></i> Timetable</a></li>
            <?php endif; ?>
        </ul>
    </div>

    <div class="main-content">
        <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
        <?php if ($message): ?><p class="message"><?php echo htmlspecialchars($message); ?></p><?php endif; ?>

        <div id="attendance" class="section active">
            <h2>Attendance Management</h2>
            <a href="?generate_qr=1" class="btn btn-primary"><i class="fas fa-qrcode"></i> Generate QR Code</a>
            <button class="btn btn-primary" onclick="openModal('manualAttendance')"><i class="fas fa-pen"></i> Mark Manually</button>
            <button class="btn btn-primary" onclick="downloadExcel()"><i class="fas fa-file-excel"></i> Download Report</button>
            <?php if ($qr_file): ?>
                <div id="qr-code" style="margin-top: 20px;">
                    <img src="<?php echo $qr_file; ?>" alt="QR Code">
                    <p>Valid for 10 minutes</p>
                </div>
            <?php endif; ?>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>Date</th><th>PRN</th><th>Status</th><th>Method</th></tr></thead>
                    <tbody>
                        <?php foreach ($attendance as $record): ?>
                            <tr><td><?php echo $record['date']; ?></td><td><?php echo htmlspecialchars($record['prn']); ?></td><td><?php echo $record['status']; ?></td><td><?php echo $record['method']; ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if ($role === 'Class Teacher'): ?>
            <div id="students" class="section">
                <h2>Student Management</h2>
                <button class="btn btn-primary" onclick="openModal('updateStudent')"><i class="fas fa-edit"></i> Update Student</button>
                <div class="table-wrapper">
                    <table>
                        <thead><tr><th>ID</th><th>Name</th><th>PRN</th><th>Roll No</th><th>Division</th><th>Attendance</th></tr></thead>
                        <tbody>
                            <?php foreach ($students as $student): ?>
                                <tr><td><?php echo $student['id']; ?></td><td><?php echo htmlspecialchars($student['name']); ?></td><td><?php echo htmlspecialchars($student['prn']); ?></td><td><?php echo htmlspecialchars($student['roll_no']); ?></td><td><?php echo htmlspecialchars($student['division']); ?></td><td><?php echo round($student['attendance'] ?? 0); ?>%</td></tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>

        <div id="notifications" class="section">
            <h2>Notifications</h2>
            <button class="btn btn-primary" onclick="openModal('sendNotification')"><i class="fas fa-paper-plane"></i> Send Notification</button>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>Message</th><th>Date</th></tr></thead>
                    <tbody>
                        <?php foreach ($notifications as $notif): ?>
                            <tr><td><?php echo htmlspecialchars($notif['message']); ?></td><td><?php echo $notif['created_at']; ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="schedule" class="section">
            <h2>Class Schedule</h2>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>Date</th><th>Time</th><th>Class</th><th>Room</th></tr></thead>
                    <tbody>
                        <?php foreach ($schedule as $item): ?>
                            <tr><td><?php echo $item['date']; ?></td><td><?php echo $item['time']; ?></td><td><?php echo htmlspecialchars($item['class']); ?></td><td><?php echo htmlspecialchars($item['room']); ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <?php if ($role === 'Class Teacher'): ?>
            <div id="doubts" class="section">
                <h2>Doubt-Solving System</h2>
                <div class="table-wrapper">
                    <table>
                        <thead><tr><th>Student</th><th>Query</th><th>Date</th><th>Actions</th></tr></thead>
                        <tbody>
                            <?php foreach ($doubts as $doubt): ?>
                                <tr><td><?php echo htmlspecialchars($doubt['student']); ?></td><td><?php echo htmlspecialchars($doubt['query']); ?></td><td><?php echo $doubt['created_at']; ?></td><td><button class="btn btn-primary" onclick="openReplyDoubt(<?php echo $doubt['id']; ?>)"><i class="fas fa-reply"></i> Reply</button></td></tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div id="timetable" class="section">
                <h2>Timetable Management</h2>
                <button class="btn btn-primary" onclick="openModal('updateTimetable')"><i class="fas fa-edit"></i> Update Timetable</button>
                <div class="table-wrapper">
                    <table>
                        <thead><tr><th>Day</th><th>Time</th><th>Class</th><th>Room</th></tr></thead>
                        <tbody>
                            <?php foreach ($timetable as $item): ?>
                                <tr><td><?php echo $item['day']; ?></td><td><?php echo $item['time']; ?></td><td><?php echo htmlspecialchars($item['class']); ?></td><td><?php echo htmlspecialchars($item['room']); ?></td></tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <footer>
        <span>All Rights Reserved © Designed and Developed by Yash Shastri and Team</span> | 
        <span>©PCCoER Attendance System Version v1.5 ®</span>
    </footer>

    <?php if ($is_first_login): ?>
        <div id="firstLogin" class="modal" style="display: flex;">
            <div class="modal-content">
                <h2>First-Time Registration</h2>
                <form method="POST">
                    <div class="form-group">
                        <label for="teacherEmail">Email</label>
                        <input type="email" id="teacherEmail" name="email" placeholder="name.surname@pccoer.in" required>
                    </div>
                    <div class="form-group">
                        <label for="department">Department</label>
                        <select id="department" name="department" required>
                            <option value="">Select Department</option>
                            <?php
                            $depts = $conn->query("SELECT name FROM departments_db")->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($depts as $dept) {
                                echo "<option value='{$dept['name']}'>" . htmlspecialchars($dept['name']) . "</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="role">Role</label>
                        <select id="role" name="role" required onchange="toggleDivision()">
                            <option value="">Select Role</option>
                            <option value="Regular Teacher">Regular Teacher</option>
                            <option value="Class Teacher">Class Teacher</option>
                        </select>
                    </div>
                    <div class="form-group" id="divisionGroup" style="display: none;">
                        <label for="division">Division</label>
                        <input type="text" id="division" name="division" placeholder="e.g., A">
                    </div>
                    <button type="submit" name="register_teacher" class="btn btn-primary"><i class="fas fa-sign-in-alt"></i> Register</button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <div id="manualAttendance" class="modal">
        <div class="modal-content">
            <h2>Mark Attendance Manually</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="prn">Student PRN</label>
                    <input type="text" name="prn" required>
                </div>
                <div class="form-group">
                    <label for="status">Status</label>
                    <select name="status" required>
                        <option value="">Select Status</option>
                        <option value="Present">Present</option>
                        <option value="Absent">Absent</option>
                    </select>
                </div>
                <button type="submit" name="manual_attendance" class="btn btn-primary"><i class="fas fa-check"></i> Mark</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('manualAttendance')"><i class="fas fa-times"></i> Cancel</button>
            </form>
        </div>
    </div>

    <?php if ($role === 'Class Teacher'): ?>
        <div id="updateStudent" class="modal">
            <div class="modal-content">
                <h2>Update Student</h2>
                <form method="POST">
                    <div class="form-group">
                        <label for="prn">PRN</label>
                        <input type="text" name="prn" required>
                    </div>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input type="text" name="name" required>
                    </div>
                    <div class="form-group">
                        <label for="roll_no">Roll No</label>
                        <input type="text" name="roll_no" required>
                    </div>
                    <div class="form-group">
                        <label for="division">Division</label>
                        <input type="text" name="division" required>
                    </div>
                    <button type="submit" name="update_student" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
                    <button type="button" class="btn btn-danger" onclick="closeModal('updateStudent')"><i class="fas fa-times"></i> Cancel</button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <div id="sendNotification" class="modal">
        <div class="modal-content">
            <h2>Send Notification</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea name="message" required></textarea>
                </div>
                <button type="submit" name="send_notification" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('sendNotification')"><i class="fas fa-times"></i> Cancel</button>
            </form>
        </div>
    </div>

    <?php if ($role === 'Class Teacher'): ?>
        <div id="replyDoubt" class="modal">
            <div class="modal-content">
                <h2>Reply to Doubt</h2>
                <form method="POST">
                    <input type="hidden" name="doubt_id" id="doubtId">
                    <div class="form-group">
                        <label for="reply">Your Reply</label>
                        <textarea name="reply" required></textarea>
                    </div>
                    <button type="submit" name="reply_doubt" class="btn btn-primary"><i class="fas fa-reply"></i> Send</button>
                    <button type="button" class="btn btn-danger" onclick="closeModal('replyDoubt')"><i class="fas fa-times"></i> Cancel</button>
                </form>
            </div>
        </div>

        <div id="updateTimetable" class="modal">
            <div class="modal-content">
                <h2>Update Timetable</h2>
                <form method="POST">
                    <div class="form-group">
                        <label for="day">Day</label>
                        <input type="text" name="day" required>
                    </div>
                    <div class="form-group">
                        <label for="time">Time</label>
                        <input type="text" name="time" required>
                    </div>
                    <div class="form-group">
                        <label for="class">Class</label>
                        <input type="text" name="class" required>
                    </div>
                    <div class="form-group">
                        <label for="room">Room</label>
                        <input type="text" name="room" required>
                    </div>
                    <button type="submit" name="update_timetable" class="btn btn-primary"><i class="fas fa-save"></i> Update</button>
                    <button type="button" class="btn btn-danger" onclick="closeModal('updateTimetable')"><i class="fas fa-times"></i> Cancel</button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('hidden');
            sidebar.classList.toggle('active');
            const topBar = document.querySelector('.top-bar');
            const mainContent = document.querySelector('.main-content');
            const footer = document.querySelector('footer');
            topBar.classList.toggle('full-width');
            mainContent.classList.toggle('full-width');
            footer.classList.toggle('full-width');
        }

        document.querySelectorAll('.sidebar a').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const target = this.getAttribute('href').substring(1);
                document.querySelectorAll('.section').forEach(section => section.classList.remove('active'));
                document.getElementById(target).classList.add('active');
                document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
                this.classList.add('active');
                if (window.innerWidth <= 480) toggleSidebar();
            });
        });

        function openModal(id) {
            document.getElementById(id).style.display = 'flex';
        }

        function closeModal(id) {
            document.getElementById(id).style.display = 'none';
        }

        function toggleDivision() {
            const role = document.getElementById('role').value;
            const divisionGroup = document.getElementById('divisionGroup');
            divisionGroup.style.display = role === 'Class Teacher' ? 'block' : 'none';
            document.getElementById('division').required = role === 'Class Teacher';
        }

        function openReplyDoubt(id) {
            document.getElementById('doubtId').value = id;
            openModal('replyDoubt');
        }

        function downloadExcel() {
            alert('Excel download placeholder. Implement PhpSpreadsheet logic.');
            // Example: window.location.href = 'export_attendance.php';
        }

        function showPushNotification(section) {
            if (section === 'notifications') {
                document.querySelectorAll('.push-notification').forEach((n, i) => {
                    setTimeout(() => {
                        n.style.display = 'block';
                        setTimeout(() => n.style.display = 'none', 3000);
                    }, i * 1000);
                });
            }
        }

        <?php if ($qr_file): ?>
            setTimeout(() => document.getElementById('qr-code').innerHTML = '', 600000); // Clear QR after 10 mins
        <?php endif; ?>
    </script>
</body>
</html>