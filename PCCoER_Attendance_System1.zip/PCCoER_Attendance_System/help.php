<?php
require_once 'config.php';
require_once 'functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help - PCCoER Attendance System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background-color: #f5f7fa; color: #1e2a44; padding: 20px; }
        .container { max-width: 800px; margin: 0 auto; background: #fff; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.1); }
        h1 { font-size: 28px; font-weight: 600; margin-bottom: 20px; }
        h2 { font-size: 20px; font-weight: 600; margin: 20px 0 10px; }
        p { font-size: 14px; margin-bottom: 15px; }
        ul { list-style: none; }
        ul li { margin-bottom: 10px; font-size: 14px; }
        a { color: #4b5e82; text-decoration: none; }
        a:hover { text-decoration: underline; }
        footer { text-align: center; margin-top: 20px; font-size: 12px; color: #d1d5db; background: #1e2a44; padding: 10px; border-radius: 8px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Help & Support</h1>
        <h2>Frequently Asked Questions</h2>
        <ul>
            <li><strong>How do I mark attendance?</strong> Use the QR code or face recognition option on the student dashboard.</li>
            <li><strong>What if I forget my password?</strong> Contact the admin at <a href="mailto:admin@pccoer.in">admin@pccoer.in</a>.</li>
            <li><strong>Why can't I log in?</strong> Ensure your email ends with @pccoer.in and your password is correct.</li>
        </ul>
        <h2>Contact Us</h2>
        <p>Email: <a href="mailto:@pccoer.in">support@pccoer.in</a></p>
        <p>Phone: +91-123-456-7890</p>
        <p>Address: PCCoER, Ravet, Pune, Maharashtra, India</p>
        <p><a href="index.php">Back to Home</a></p>
    </div>
    <footer>
        All Rights Reserved © Designed and Developed by Yash Shastri and Team | PCCoER Attendance System v1.5
    </footer>
</body>
</html>