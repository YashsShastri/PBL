<?php
// Start session
session_start();

// Define constants
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', ''); // Adjust if you set a password
define('DB_NAME', 'attendance_system_db');
define('UPLOAD_DIR', 'uploads/face_images/');
define('LOG_DIR', 'logs/');
define('REPORT_DIR', 'reports/');

// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Database connection
try {
    $conn = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Debug: Confirm connection
    // echo "Database connected successfully<br>";
} catch (PDOException $e) {
    file_put_contents(LOG_DIR . 'db_error.log', date('Y-m-d H:i:s') . " - " . $e->getMessage() . "\n", FILE_APPEND);
    header('Location: error.php');
    exit;
}