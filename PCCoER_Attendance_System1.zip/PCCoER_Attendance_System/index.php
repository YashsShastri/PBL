<?php
require_once 'config.php';
$notifications = $conn->query("SELECT message FROM notification_db ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_COLUMN);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PCCoER Attendance System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background: #f5f7fa; color: #1e2a44; line-height: 1.6; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; text-align: center; }
        header { background: #1e2a44; color: #fff; padding: 15px; }
        header h1 { font-size: 28px; font-weight: 600; }
        .logo { max-width: 120px; margin: 15px auto; }
        .banner { margin: 15px 0; }
        .banner img { max-width: 100%; height: auto; border-radius: 8px; }
        .notifications { background: #fff; padding: 10px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,.05); margin: 15px 0; overflow: hidden; height: 40px; }
        .notifications .scroll { display: flex; animation: scroll 20s linear infinite; white-space: nowrap; }
        .notifications .scroll span { margin-right: 30px; font-size: 14px; color: #4b5e82; }
        @keyframes scroll { 0% { transform: translateX(100%); } 100% { transform: translateX(-100%); } }
        .btn { padding: 10px 18px; border: none; border-radius: 8px; background: #4b5e82; color: #fff; font-size: 14px; cursor: pointer; transition: all .3s ease; }
        .btn:hover { background: #3b4a6b; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,.1); }
        footer { background: #1e2a44; color: #d1d5db; padding: 10px; text-align: center; position: fixed; bottom: 0; width: 100%; font-size: 12px; }
        footer a { color: #fff; text-decoration: none; }
        @media (max-width: 480px) {
            header h1 { font-size: 20px; }
            .logo { max-width: 100px; }
            .notifications { height: 30px; }
            .notifications .scroll span { font-size: 12px; margin-right: 20px; }
            .btn { font-size: 12px; padding: 8px 15px; }
            footer { font-size: 10px; }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>PCCoER Attendance System</h1>
        </div>
    </header>
    <div class="container">
        <img src="https://via.placeholder.com/150" alt="PCCoER Logo" class="logo">
        <p>Welcome to Pimpri Chinchwad College of Engineering, Ravet | PUNE</p>
        <div class="banner">
            <img src="https://via.placeholder.com/800x200" alt="Event Banner">
        </div>
        <div class="notifications">
            <div class="scroll">
                <?php foreach ($notifications as $msg): ?>
                    <span><?php echo htmlspecialchars($msg); ?></span>
                <?php endforeach; ?>
            </div>
        </div>
        <a href="login.php" class="btn">Login</a>
    </div>
    <footer>
        <p>  ©  All Rights Reserved © Designed and Developed by Yash Shastri and Team | <a href="help.php">Help</a></p>
    </footer>
</body>
</html>