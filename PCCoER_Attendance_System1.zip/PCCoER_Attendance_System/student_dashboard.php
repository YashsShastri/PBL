<?php
require_once 'config.php';
require_once 'functions.php';

redirectIfNotLoggedIn();
$user_id = $_SESSION['user_id'];
$role = getUserRole();
if ($role !== 'Student') {
    header('Location: index.php');
    exit;
}

// Check if first-time login
$is_first_login = $_SESSION['first_login'] ?? false;

// Fetch student details
$stmt = $conn->prepare("SELECT u.email, u.name, s.prn, s.roll_no, d.name AS division, s.division_id FROM users_db u JOIN students_db s ON u.id = s.user_id JOIN division_db d ON s.division_id = d.id WHERE u.id = :id");
$stmt->execute(['id' => $user_id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);
$division_id = $student['division_id'] ?? null;

// Handle form submissions
$error = $message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['register_student'])) {
            $email = trim($_POST['email']);
            $division = trim($_POST['division']);
            $roll_no = trim($_POST['roll_no']);
            $prn = trim($_POST['prn']);
            $face_image = $_FILES['face_image'];
            if (!preg_match('/^[a-z]+\.[a-z]+_[a-z]+[0-9]+@pccoer\.in$/', $email)) {
                throw new Exception("Invalid email format. Use name.surname_branchyear@pccoer.in");
            }
            if ($face_image['error'] === UPLOAD_ERR_OK) {
                $upload_dir = 'uploads/student_faces/';
                if (!is_dir($upload_dir)) mkdir($upload_dir, 0777, true);
                $face_path = $upload_dir . $user_id . '_' . time() . '.jpg';
                move_uploaded_file($face_image['tmp_name'], $face_path);
            } else {
                throw new Exception("Failed to upload face image.");
            }
            $stmt = $conn->prepare("UPDATE users_db SET email = :email, name = :name, first_login = FALSE WHERE id = :id");
            $stmt->execute(['email' => $email, 'name' => explode('@', $email)[0], 'id' => $user_id]);
            $stmt = $conn->prepare("INSERT INTO students_db (user_id, division_id, prn, roll_no, face_image_path) VALUES (:user_id, (SELECT id FROM division_db WHERE name = :division LIMIT 1), :prn, :roll_no, :face_path) ON DUPLICATE KEY UPDATE prn = :prn, roll_no = :roll_no, face_image_path = :face_path, division_id = (SELECT id FROM division_db WHERE name = :division LIMIT 1)");
            $stmt->execute(['user_id' => $user_id, 'division' => $division, 'prn' => $prn, 'roll_no' => $roll_no, 'face_path' => $face_path]);
            $_SESSION['first_login'] = false;
            $is_first_login = false;
            $message = "Registration completed successfully.";
            logAction($user_id, "Completed first-time registration");
            header("Refresh:0"); // Refresh to update student data
        } elseif (isset($_POST['submit_doubt'])) {
            $query = trim($_POST['query']);
            $stmt = $conn->prepare("INSERT INTO doubts_db (student_id, division_id, query, created_at) VALUES (:student_id, :division_id, :query, NOW())");
            $stmt->execute(['student_id' => $user_id, 'division_id' => $division_id, 'query' => $query]);
            logAction($user_id, "Submitted doubt: $query");
            $message = "Doubt submitted successfully.";
        } elseif (isset($_POST['mark_attendance'])) {
            $method = $_POST['method'];
            $stmt = $conn->prepare("INSERT INTO attendance_db (student_id, date, status, method, teacher_id) VALUES (:student_id, NOW(), 'Present', :method, (SELECT user_id FROM class_teachers_db WHERE division_id = :division_id LIMIT 1))");
            $stmt->execute(['student_id' => $user_id, 'method' => $method, 'division_id' => $division_id]);
            logAction($user_id, "Marked attendance via $method");
            $message = "Attendance marked successfully.";
        }
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Fetch data
if (!$is_first_login) {
    $attendance = $conn->prepare("SELECT date, status, method FROM attendance_db WHERE student_id = :student_id ORDER BY date DESC LIMIT 50");
    $attendance->execute(['student_id' => $user_id]);
    $attendance = $attendance->fetchAll(PDO::FETCH_ASSOC);

    $schedule = $conn->prepare("SELECT date, time, class, room FROM schedule_db WHERE division_id = :division_id ORDER BY date, time");
    $schedule->execute(['division_id' => $division_id]);
    $schedule = $schedule->fetchAll(PDO::FETCH_ASSOC);

    $notifications = $conn->prepare("SELECT n.message, n.created_at FROM notification_db n JOIN class_teachers_db ct ON n.user_id = ct.user_id WHERE ct.division_id = :division_id ORDER BY n.created_at DESC LIMIT 5");
    $notifications->execute(['division_id' => $division_id]);
    $notifications = $notifications->fetchAll(PDO::FETCH_ASSOC);

    $doubts = $conn->prepare("SELECT query, created_at, reply, replied_at FROM doubts_db WHERE student_id = :student_id ORDER BY created_at DESC");
    $doubts->execute(['student_id' => $user_id]);
    $doubts = $doubts->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PCCoER Student Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background-color: #f5f7fa; color: #1e2a44; line-height: 1.6; overflow-x: hidden; }
        .sidebar { position: fixed; top: 0; left: 0; width: 270px; height: 100%; background: linear-gradient(180deg, #1e2a44 0%, #172038 100%); color: #d1d5db; padding: 20px; transition: transform .3s ease; box-shadow: 2px 0 15px rgba(0,0,0,.05); z-index: 1000; }
        .sidebar.hidden { transform: translateX(-270px); }
        .sidebar .logo { font-size: 22px; font-weight: 600; margin-bottom: 30px; text-align: center; color: #fff; }
        .sidebar ul { list-style: none; }
        .sidebar ul li { margin: 15px 0; }
        .sidebar ul li a { color: #d1d5db; text-decoration: none; font-size: 14px; font-weight: 400; display: flex; align-items: center; padding: 10px 15px; border-radius: 8px; transition: all .3s ease; }
        .sidebar ul li a.active, .sidebar ul li a:hover { background-color: #3b4a6b; color: #fff; }
        .sidebar ul li a i { margin-right: 10px; font-size: 16px; }
        .top-bar { position: fixed; top: 0; left: 270px; width: calc(100% - 270px); background: #fff; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,.05); transition: left .3s ease, width .3s ease; z-index: 999; }
        .top-bar.full-width { left: 0; width: 100%; }
        .top-bar .user-info { display: flex; align-items: center; gap: 10px; }
        .top-bar .user-info span { font-weight: 500; font-size: 14px; }
        .top-bar .controls { display: flex; align-items: center; gap: 15px; }
        .top-bar .hamburger { font-size: 20px; cursor: pointer; color: #4b5e82; }
        .top-bar .notifications { position: relative; }
        .top-bar .notifications i { font-size: 18px; cursor: pointer; color: #4b5e82; }
        .top-bar .notifications .badge { position: absolute; top: -5px; right: -5px; background-color: #e63946; color: #fff; font-size: 10px; padding: 2px 5px; border-radius: 50%; }
        .main-content { margin-left: 270px; margin-top: 60px; padding: 20px; min-height: calc(100vh - 100px); transition: margin-left .3s ease; }
        .main-content.full-width { margin-left: 0; }
        .section { display: none; background: #fff; padding: 20px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.05); margin-bottom: 20px; }
        .section.active { display: block; }
        h2 { font-size: 20px; font-weight: 600; margin-bottom: 15px; position: relative; }
        h2::after { content: ''; position: absolute; bottom: -5px; left: 0; width: 30px; height: 2px; background: #4b5e82; }
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; background: #fff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.05); }
        table th, table td { padding: 10px; text-align: left; font-size: 12px; }
        table th { background: #4b5e82; color: #fff; font-weight: 500; }
        table tr { transition: background .3s ease; }
        table tr:hover { background: #f9fafb; }
        table td { border-bottom: 1px solid #e5e7eb; }
        .btn { padding: 10px 15px; border: none; border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 500; transition: all .3s ease; display: inline-flex; align-items: center; gap: 5px; }
        .btn-primary { background: #4b5e82; color: #fff; }
        .btn-primary:hover { background: #3b4a6b; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,.1); }
        .btn-danger { background: #e63946; color: #fff; }
        .btn-danger:hover { background: #c53030; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,.1); }
        .btn i { font-size: 14px; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,.7); justify-content: center; align-items: center; z-index: 1000; }
        .modal-content { background: #fff; padding: 20px; border-radius: 12px; width: 90%; max-width: 500px; box-shadow: 0 6px 25px rgba(0,0,0,.15); }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-weight: 500; margin-bottom: 5px; font-size: 14px; }
        .form-group input, .form-group textarea { width: 100%; padding: 10px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; }
        .error { color: #e63946; text-align: center; margin-bottom: 10px; font-size: 12px; }
        .message { color: #2d6a4f; text-align: center; margin-bottom: 10px; font-size: 12px; }
        .location-box { width: 100%; height: 150px; background: #fff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.05); margin-top: 15px; display: flex; justify-content: center; align-items: center; flex-direction: column; }
        .dot { width: 20px; height: 20px; border-radius: 50%; animation: blink 1s infinite; }
        .dot.green { background: #2d6a4f; }
        .dot.red { background: #e63946; }
        @keyframes blink { 0% { opacity: 1; } 50% { opacity: 0.3; } 100% { opacity: 1; } }
        .location-msg { margin-top: 10px; font-size: 14px; font-weight: 500; }
        footer { position: fixed; bottom: 0; left: 270px; width: calc(100% - 270px); background: #1e2a44; color: #d1d5db; padding: 10px 20px; text-align: center; font-size: 12px; transition: left .3s ease, width .3s ease; z-index: 998; }
        footer.full-width { left: 0; width: 100%; }
        footer span { margin: 0 5px; }
        @media (max-width: 768px) {
            .sidebar { width: 220px; }
            .main-content { margin-left: 220px; }
            .top-bar { left: 220px; width: calc(100% - 220px); }
            footer { left: 220px; width: calc(100% - 220px); }
        }
        @media (max-width: 480px) {
            .sidebar { width: 100%; height: auto; position: relative; transform: translateX(-100%); padding: 10px; }
            .sidebar.hidden { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .top-bar { left: 0; width: 100%; padding: 10px; }
            .top-bar .user-info span { font-size: 12px; }
            .top-bar .hamburger { font-size: 18px; }
            .main-content { margin-left: 0; margin-top: 50px; padding: 10px; }
            h2 { font-size: 18px; }
            .location-box { height: 120px; }
            .location-msg { font-size: 12px; }
            .btn { font-size: 10px; padding: 8px 12px; }
            table th, table td { font-size: 10px; padding: 8px; }
            footer { font-size: 10px; padding: 8px; }
        }
    </style>
</head>
<body>
    <div class="top-bar">
        <div class="user-info">
            <i class="fas fa-bars hamburger" onclick="toggleSidebar()"></i>
            <span><?php echo htmlspecialchars($student['name'] ?? 'Student'); ?></span>
        </div>
        <div class="controls">
            <div class="notifications">
                <i class="fas fa-bell" onclick="showPushNotification('notifications')"></i>
                <span class="badge"><?php echo count($notifications); ?></span>
                <?php foreach ($notifications as $i => $notif): ?>
                    <div class="push-notification <?php echo ['important', 'normal', 'medium'][$i % 3]; ?>" id="push-<?php echo $i; ?>"><?php echo htmlspecialchars($notif['message']); ?></div>
                <?php endforeach; ?>
            </div>
            <a href="logout.php" class="btn btn-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>

    <div class="sidebar hidden">
        <div class="logo">PCCoER Student</div>
        <ul>
            <li><a href="#attendance" class="active"><i class="fas fa-calendar-check"></i> Attendance</a></li>
            <li><a href="#schedule"><i class="fas fa-clock"></i> Schedule</a></li>
            <li><a href="#notifications"><i class="fas fa-bell"></i> Notifications</a></li>
            <li><a href="#doubts"><i class="fas fa-question-circle"></i> Doubts</a></li>
        </ul>
    </div>

    <div class="main-content">
        <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
        <?php if ($message): ?><p class="message"><?php echo htmlspecialchars($message); ?></p><?php endif; ?>

        <div id="attendance" class="section active">
            <h2>Attendance System</h2>
            <div class="location-box">
                <div id="location-dot" class="dot"></div>
                <span id="location-msg" class="location-msg">Checking location...</span>
            </div>
            <form method="POST" style="margin-top: 15px;">
                <input type="hidden" name="method" value="QR">
                <button type="submit" name="mark_attendance" class="btn btn-primary" id="qrBtn" disabled><i class="fas fa-qrcode"></i> Scan QR Code</button>
            </form>
            <form method="POST" style="margin-top: 15px;">
                <input type="hidden" name="method" value="Face">
                <button type="submit" name="mark_attendance" class="btn btn-primary" id="faceBtn" disabled><i class="fas fa-camera"></i> Face Recognition</button>
            </form>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>Date</th><th>Status</th><th>Method</th></tr></thead>
                    <tbody>
                        <?php foreach ($attendance as $record): ?>
                            <tr><td><?php echo $record['date']; ?></td><td><?php echo $record['status']; ?></td><td><?php echo $record['method']; ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="schedule" class="section">
            <h2>Class Schedule</h2>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>Date</th><th>Time</th><th>Class</th><th>Room</th></tr></thead>
                    <tbody>
                        <?php foreach ($schedule as $item): ?>
                            <tr><td><?php echo $item['date']; ?></td><td><?php echo $item['time']; ?></td><td><?php echo htmlspecialchars($item['class']); ?></td><td><?php echo htmlspecialchars($item['room']); ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="notifications" class="section">
            <h2>Notifications</h2>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>Message</th><th>Date</th></tr></thead>
                    <tbody>
                        <?php foreach ($notifications as $notif): ?>
                            <tr><td><?php echo htmlspecialchars($notif['message']); ?></td><td><?php echo $notif['created_at']; ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div id="doubts" class="section">
            <h2>Doubt System</h2>
            <button class="btn btn-primary" onclick="openModal('submitDoubt')"><i class="fas fa-question"></i> Submit Doubt</button>
            <div class="table-wrapper" style="margin-top: 15px;">
                <table>
                    <thead><tr><th>Query</th><th>Date</th><th>Reply</th></tr></thead>
                    <tbody>
                        <?php foreach ($doubts as $doubt): ?>
                            <tr><td><?php echo htmlspecialchars($doubt['query']); ?></td><td><?php echo $doubt['created_at']; ?></td><td><?php echo htmlspecialchars($doubt['reply'] ?? 'Awaiting reply'); ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <footer>
        <span>All Rights Reserved © Designed and Developed by Yash Shastri and Team</span> | 
        <span>©PCCoER Attendance System Version v1.5 ®</span>
    </footer>

    <?php if ($is_first_login): ?>
        <div id="firstLogin" class="modal" style="display: flex;">
            <div class="modal-content">
                <h2>First-Time Registration</h2>
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="studentEmail">Email</label>
                        <input type="email" id="studentEmail" name="email" placeholder="name.surname_branchyear@pccoer.in" required>
                    </div>
                    <div class="form-group">
                        <label for="division">Division</label>
                        <input type="text" id="division" name="division" placeholder="e.g., A" required>
                    </div>
                    <div class="form-group">
                        <label for="rollNo">Roll Number</label>
                        <input type="text" id="rollNo" name="roll_no" required>
                    </div>
                    <div class="form-group">
                        <label for="prn">PRN Number</label>
                        <input type="text" id="prn" name="prn" required>
                    </div>
                    <div class="form-group">
                        <label for="faceImage">Face Image</label>
                        <input type="file" id="faceImage" name="face_image" accept="image/*" required>
                    </div>
                    <button type="submit" name="register_student" class="btn btn-primary"><i class="fas fa-sign-in-alt"></i> Register</button>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <div id="submitDoubt" class="modal">
        <div class="modal-content">
            <h2>Submit Doubt</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="query">Your Question</label>
                    <textarea name="query" required></textarea>
                </div>
                <button type="submit" name="submit_doubt" class="btn btn-primary"><i class="fas fa-question"></i> Submit</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('submitDoubt')"><i class="fas fa-times"></i> Cancel</button>
            </form>
        </div>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('hidden');
            sidebar.classList.toggle('active');
            const topBar = document.querySelector('.top-bar');
            const mainContent = document.querySelector('.main-content');
            const footer = document.querySelector('footer');
            topBar.classList.toggle('full-width');
            mainContent.classList.toggle('full-width');
            footer.classList.toggle('full-width');
        }

        document.querySelectorAll('.sidebar a').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const target = this.getAttribute('href').substring(1);
                document.querySelectorAll('.section').forEach(section => section.classList.remove('active'));
                document.getElementById(target).classList.add('active');
                document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
                this.classList.add('active');
                if (window.innerWidth <= 480) toggleSidebar();
            });
        });

        function openModal(id) {
            document.getElementById(id).style.display = 'flex';
        }

        function closeModal(id) {
            document.getElementById(id).style.display = 'none';
        }

        let isInsideCampus = false;
        function checkLocation() {
            navigator.geolocation.getCurrentPosition(
                (position) => {
                    const lat = position.coords.latitude;
                    const lon = position.coords.longitude;
                    const pccoerLat = 18.6529; // Replace with actual PCCoER coordinates
                    const pccoerLon = 73.8471;
                    const distance = getDistance(lat, lon, pccoerLat, pccoerLon);
                    const dot = document.getElementById('location-dot');
                    const msg = document.getElementById('location-msg');
                    if (distance < 0.5) { // Within 500m
                        dot.classList.remove('red');
                        dot.classList.add('green');
                        msg.textContent = 'You are inside campus';
                        isInsideCampus = true;
                        document.getElementById('qrBtn').disabled = false;
                        document.getElementById('faceBtn').disabled = false;
                    } else {
                        dot.classList.remove('green');
                        dot.classList.add('red');
                        msg.textContent = 'You are outside campus';
                        isInsideCampus = false;
                    }
                },
                () => {
                    document.getElementById('location-msg').textContent = 'Location access denied';
                    document.getElementById('location-dot').classList.add('red');
                    isInsideCampus = false;
                }
            );
        }

        function getDistance(lat1, lon1, lat2, lon2) {
            const R = 6371; // Earth's radius in km
            const dLat = (lat2 - lat1) * Math.PI / 180;
            const dLon = (lon2 - lon1) * Math.PI / 180;
            const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                      Math.sin(dLon/2) * Math.sin(dLon/2);
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            return R * c; // Distance in km
        }

        function showPushNotification(section) {
            if (section === 'notifications') {
                document.querySelectorAll('.push-notification').forEach((n, i) => {
                    setTimeout(() => {
                        n.style.display = 'block';
                        setTimeout(() => n.style.display = 'none', 3000);
                    }, i * 1000);
                });
            }
        }

        <?php if (!$is_first_login): ?>
            checkLocation();
            setInterval(checkLocation, 60000); // Recheck every minute
        <?php endif; ?>
    </script>
</body>
</html>