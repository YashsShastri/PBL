<?php
// Include config.php with absolute path
require_once 'C:/xampp/htdocs/PCCoER_Attendance_System/config.php';

// Debug: Confirm this file is loaded
// echo "functions.php loaded<br>";

function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

function redirectIfNotLoggedIn() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit;
    }
}

function getUserRole() {
    return $_SESSION['role'] ?? null;
}

function redirectToDashboard() {
    $role = getUserRole();
    switch ($role) {
        case 'Admin': 
            header('Location: admin_dashboard.php'); 
            break;
        case 'Regular Teacher':
        case 'Class Teacher': 
            header('Location: teacher_dashboard.php'); 
            break;
        case 'Student': 
            header('Location: student_dashboard.php'); 
            break;
        default: 
            header('Location: index.php');
    }
    exit;
}

function logAction($user_id, $action) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO logs_db (user_id, action, timestamp) VALUES (:user_id, :action, NOW())");
    $stmt->execute(['user_id' => $user_id, 'action' => $action]);
    file_put_contents(LOG_DIR . 'system.log', date('Y-m-d H:i:s') . " - User $user_id: $action\n", FILE_APPEND);
}