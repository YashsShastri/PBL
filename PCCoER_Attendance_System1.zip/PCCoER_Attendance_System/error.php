<?php
require_once 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Error - PCCoER Attendance System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background-color: #f5f7fa; color: #1e2a44; display: flex; justify-content: center; align-items: center; height: 100vh; }
        .error-container { background: #fff; padding: 40px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.1); text-align: center; }
        h1 { font-size: 28px; font-weight: 600; margin-bottom: 20px; color: #e63946; }
        p { font-size: 14px; margin-bottom: 20px; }
        a { color: #4b5e82; text-decoration: none; font-size: 12px; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="error-container">
        <h1>Oops! Something Went Wrong</h1>
        <p>We encountered an error. Please try again later or contact support.</p>
        <a href="index.php">Back to Home</a>
    </div>
</body>
</html>