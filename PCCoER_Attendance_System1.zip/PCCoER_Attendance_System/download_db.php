<?php
require_once 'config.php';
redirectIfNotLoggedIn();
if (getUserRole() !== 'Admin') exit;

// Define mysqldump path explicitly (adjust if XAMPP is installed elsewhere)
$mysqldump_path = "C:\\xampp\\mysql\\bin\\mysqldump.exe";
$filename = "attendance_system_db_" . date('Ymd') . ".sql";
$command = "\"$mysqldump_path\" -u root -h localhost attendance_system_db > $filename 2>&1";
exec($command, $output, $return_var);

if ($return_var !== 0) {
    die("Error exporting database: " . implode("\n", $output));
}

header('Content-Type: application/octet-stream');
header("Content-Disposition: attachment; filename=$filename");
readfile($filename);
unlink($filename);
exit;
?>