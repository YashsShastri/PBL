// Sidebar Toggle
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('hidden');
    sidebar.classList.toggle('active');
    const topBar = document.querySelector('.top-bar');
    const mainContent = document.querySelector('.main-content');
    const footer = document.querySelector('footer');
    topBar.classList.toggle('full-width');
    mainContent.classList.toggle('full-width');
    footer.classList.toggle('full-width');
}

// Navigation
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.sidebar a').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('href').substring(1);
            document.querySelectorAll('.section').forEach(section => section.classList.remove('active'));
            document.getElementById(target).classList.add('active');
            document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
            this.classList.add('active');
            if (window.innerWidth <= 480) toggleSidebar();
        });
    });
});

// Modal Controls
function openModal(id) {
    document.getElementById(id).style.display = 'flex';
}

function closeModal(id) {
    document.getElementById(id).style.display = 'none';
}

// Location Check
let isInsideCampus = false;
function checkLocation() {
    navigator.geolocation.getCurrentPosition(
        (position) => {
            const lat = position.coords.latitude;
            const lon = position.coords.longitude;
            const pccoerLat = 18.6529; // Replace with actual PCCoER coordinates
            const pccoerLon = 73.8471;
            const distance = getDistance(lat, lon, pccoerLat, pccoerLon);
            const dot = document.getElementById('location-dot');
            const msg = document.getElementById('location-msg');
            const qrBtn = document.getElementById('qrBtn');
            const faceBtn = document.getElementById('faceBtn');
            if (distance < 0.5) { // Within 500m
                dot.classList.remove('red');
                dot.classList.add('green');
                msg.textContent = 'You are inside campus';
                isInsideCampus = true;
                if (qrBtn) qrBtn.disabled = false;
                if (faceBtn) faceBtn.disabled = false;
            } else {
                dot.classList.remove('green');
                dot.classList.add('red');
                msg.textContent = 'You are outside campus';
                isInsideCampus = false;
                if (qrBtn) qrBtn.disabled = true;
                if (faceBtn) faceBtn.disabled = true;
            }
        },
        () => {
            document.getElementById('location-msg').textContent = 'Location access denied';
            document.getElementById('location-dot').classList.add('red');
            isInsideCampus = false;
            const qrBtn = document.getElementById('qrBtn');
            const faceBtn = document.getElementById('faceBtn');
            if (qrBtn) qrBtn.disabled = true;
            if (faceBtn) faceBtn.disabled = true;
        }
    );
}

function getDistance(lat1, lon1, lat2, lon2) {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c; // Distance in km
}

// Face Recognition (Frontend Trigger)
function triggerFaceRecognition() {
    if (!isInsideCampus) {
        alert('You must be inside campus to use face recognition');
        return;
    }
    const video = document.createElement('video');
    video.setAttribute('autoplay', '');
    video.setAttribute('muted', '');
    video.setAttribute('playsinline', '');
    navigator.mediaDevices.getUserMedia({ video: true })
        .then(stream => {
            video.srcObject = stream;
            const canvas = document.createElement('canvas');
            const ctx = canvas.getContext('2d');
            video.addEventListener('play', () => {
                canvas.width = video.videoWidth;
                canvas.height = video.videoHeight;
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                canvas.toBlob(blob => {
                    const formData = new FormData();
                    formData.append('image', blob, 'capture.jpg');
                    fetch('face_recognition_handler.php', {
                        method: 'POST',
                        body: formData
                    })
                    .then(response => response.json())
                    .then(data => {
                        stream.getTracks().forEach(track => track.stop());
                        if (data.status === 'success') {
                            alert(`Recognized: ${data.name} (Confidence: ${(data.confidence * 100).toFixed(2)}%)`);
                        } else if (data.status === 'unknown') {
                            alert('No match found');
                        } else {
                            alert(`Error: ${data.message}`);
                        }
                    });
                }, 'image/jpeg');
            });
        })
        .catch(err => alert('Camera access denied: ' + err.message));
}

// Initial Setup (Called from PHP if not first login)
function initialize() {
    checkLocation();
    setInterval(checkLocation, 60000); // Recheck every minute
}