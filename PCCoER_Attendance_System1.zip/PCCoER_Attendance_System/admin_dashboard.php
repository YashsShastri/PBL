<?php
require_once 'config.php';
require_once 'functions.php';
redirectIfNotLoggedIn();
if (getUserRole() !== 'Admin') {
    header('Location: index.php');
    exit;
}
if ($_SESSION['first_login']) {
    header('Location: register.php');
    exit;
}

// Handle form submissions
$error = $message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['add_student'])) {
            $email = trim($_POST['email']);
            $name = trim($_POST['name']);
            $dept = trim($_POST['department']);
            $division = trim($_POST['division']);
            $prn = trim($_POST['prn']);
            $roll_no = trim($_POST['roll_no']);
            $stmt = $conn->prepare("INSERT INTO users_db (email, password, role, name, first_login) VALUES (:email, :password, 'Student', :name, TRUE)");
            $stmt->execute(['email' => $email, 'password' => password_hash('student123', PASSWORD_DEFAULT), 'name' => $name]);
            $user_id = $conn->lastInsertId();
            $stmt = $conn->prepare("INSERT INTO students_db (user_id, division_id, prn, roll_no) VALUES (:user_id, (SELECT id FROM division_db WHERE name = :division AND department_id = (SELECT id FROM departments_db WHERE name = :dept)), :prn, :roll_no)");
            $stmt->execute(['user_id' => $user_id, 'division' => $division, 'dept' => $dept, 'prn' => $prn, 'roll_no' => $roll_no]);
            logAction($_SESSION['user_id'], "Added student: $email");
            $message = "Student added successfully.";
        } elseif (isset($_POST['add_teacher'])) {
            $email = trim($_POST['email']);
            $name = trim($_POST['name']);
            $dept = trim($_POST['department']);
            $stmt = $conn->prepare("INSERT INTO users_db (email, password, role, name, department_id, first_login) VALUES (:email, :password, 'Teacher', :name, (SELECT id FROM departments_db WHERE name = :dept), TRUE)");
            $stmt->execute(['email' => $email, 'password' => password_hash('teacher123', PASSWORD_DEFAULT), 'name' => $name, 'dept' => $dept]);
            logAction($_SESSION['user_id'], "Added teacher: $email");
            $message = "Teacher added successfully.";
        } elseif (isset($_POST['add_admin'])) {
            $email = trim($_POST['email']);
            $name = trim($_POST['name']);
            $role = $_POST['role'];
            $stmt = $conn->prepare("INSERT INTO users_db (email, password, role, name, first_login) VALUES (:email, :password, :role, :name, FALSE)");
            $stmt->execute(['email' => $email, 'password' => password_hash('admin123', PASSWORD_DEFAULT), 'role' => $role, 'name' => $name]);
            logAction($_SESSION['user_id'], "Added admin: $email");
            $message = "Admin added successfully.";
        } elseif (isset($_POST['edit_student'])) {
            $id = (int)$_POST['id'];
            $email = trim($_POST['email']);
            $name = trim($_POST['name']);
            $dept = trim($_POST['department']);
            $division = trim($_POST['division']);
            $prn = trim($_POST['prn']);
            $roll_no = trim($_POST['roll_no']);
            $stmt = $conn->prepare("UPDATE users_db SET email = :email, name = :name WHERE id = (SELECT user_id FROM students_db WHERE id = :id)");
            $stmt->execute(['email' => $email, 'name' => $name, 'id' => $id]);
            $stmt = $conn->prepare("UPDATE students_db SET division_id = (SELECT id FROM division_db WHERE name = :division AND department_id = (SELECT id FROM departments_db WHERE name = :dept)), prn = :prn, roll_no = :roll_no WHERE id = :id");
            $stmt->execute(['division' => $division, 'dept' => $dept, 'prn' => $prn, 'roll_no' => $roll_no, 'id' => $id]);
            logAction($_SESSION['user_id'], "Edited student ID: $id");
            $message = "Student updated successfully.";
        } elseif (isset($_POST['delete_student'])) {
            $id = (int)$_POST['id'];
            $stmt = $conn->prepare("DELETE FROM students_db WHERE id = :id");
            $stmt->execute(['id' => $id]);
            $stmt = $conn->prepare("DELETE FROM users_db WHERE id = (SELECT user_id FROM students_db WHERE id = :id)");
            $stmt->execute(['id' => $id]);
            logAction($_SESSION['user_id'], "Deleted student ID: $id");
            $message = "Student deleted successfully.";
        } elseif (isset($_POST['edit_teacher'])) {
            $id = (int)$_POST['id'];
            $email = trim($_POST['email']);
            $name = trim($_POST['name']);
            $stmt = $conn->prepare("UPDATE users_db SET email = :email, name = :name WHERE id = :id");
            $stmt->execute(['email' => $email, 'name' => $name, 'id' => $id]);
            logAction($_SESSION['user_id'], "Edited teacher ID: $id");
            $message = "Teacher updated successfully.";
        } elseif (isset($_POST['delete_teacher'])) {
            $id = (int)$_POST['id'];
            $stmt = $conn->prepare("DELETE FROM users_db WHERE id = :id");
            $stmt->execute(['id' => $id]);
            logAction($_SESSION['user_id'], "Deleted teacher ID: $id");
            $message = "Teacher deleted successfully.";
        } elseif (isset($_POST['notification'])) {
            $stmt = $conn->prepare("INSERT INTO notification_db (message) VALUES (:message)");
            $stmt->execute(['message' => trim($_POST['notification'])]);
            logAction($_SESSION['user_id'], "Sent notification: " . $_POST['notification']);
            $message = "Notification sent successfully.";
        } elseif (isset($_FILES['excel_upload'])) {
            $data = parseExcel($_FILES['excel_upload']['tmp_name']);
            foreach ($data as $row) {
                [$email, $name, $dept, $division, $prn, $roll_no] = array_pad($row, 6, '');
                $stmt = $conn->prepare("INSERT INTO users_db (email, password, role, name, first_login) VALUES (:email, :password, 'Student', :name, TRUE)");
                $stmt->execute(['email' => $email, 'password' => password_hash('student123', PASSWORD_DEFAULT), 'name' => $name]);
                $user_id = $conn->lastInsertId();
                $stmt = $conn->prepare("INSERT INTO students_db (user_id, division_id, prn, roll_no) VALUES (:user_id, (SELECT id FROM division_db WHERE name = :division AND department_id = (SELECT id FROM departments_db WHERE name = :dept)), :prn, :roll_no)");
                $stmt->execute(['user_id' => $user_id, 'division' => $division, 'dept' => $dept, 'prn' => $prn, 'roll_no' => $roll_no]);
            }
            logAction($_SESSION['user_id'], "Uploaded Excel with " . count($data) . " students");
            $message = "Students uploaded successfully.";
        }
    } catch (Exception $e) {
        $error = "Error: " . $e->getMessage();
    }
}

// Fetch data for display
$departments = $conn->query("SELECT * FROM departments_db")->fetchAll(PDO::FETCH_ASSOC);
$students = $conn->query("SELECT s.id, u.email, u.name, d.name AS dept, div.name AS division, s.prn, s.roll_no FROM students_db s JOIN users_db u ON s.user_id = u.id JOIN division_db div ON s.division_id = div.id JOIN departments_db d ON div.department_id = d.id")->fetchAll(PDO::FETCH_ASSOC);
$teachers = $conn->query("SELECT id, email, name FROM users_db WHERE role = 'Teacher'")->fetchAll(PDO::FETCH_ASSOC);
$admins = $conn->query("SELECT id, email, name, role FROM users_db WHERE role IN ('Admin', 'Partial Admin')")->fetchAll(PDO::FETCH_ASSOC);
$attendance = $conn->query("SELECT date, student_id, status, method FROM attendance_db")->fetchAll(PDO::FETCH_ASSOC);
$logs = $conn->query("SELECT l.timestamp, u.email, l.action FROM system_log_db l JOIN users_db u ON l.user_id = u.id ORDER BY l.timestamp DESC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);
$notifications = $conn->query("SELECT message, created_at FROM notification_db ORDER BY created_at DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>PCCoER Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background-color: #f5f7fa; color: #1e2a44; line-height: 1.6; overflow-x: hidden; }
        .sidebar { position: fixed; top: 0; left: 0; width: 270px; height: 100%; background: linear-gradient(180deg, #1e2a44 0%, #172038 100%); color: #d1d5db; padding: 20px; transition: transform .3s ease; box-shadow: 2px 0 15px rgba(0,0,0,.05); z-index: 1000; }
        .sidebar.hidden { transform: translateX(-270px); }
        .sidebar .logo { font-size: 22px; font-weight: 600; margin-bottom: 15px; text-align: center; color: #fff; }
        .sidebar .search-bar { margin-bottom: 15px; }
        .sidebar .search-bar input { width: 100%; padding: 8px; border: none; border-radius: 8px; font-size: 12px; }
        .sidebar ul { list-style: none; }
        .sidebar ul li { margin: 15px 0; }
        .sidebar ul li a { color: #d1d5db; text-decoration: none; font-size: 14px; font-weight: 400; display: flex; align-items: center; padding: 10px 15px; border-radius: 8px; transition: all .3s ease; }
        .sidebar ul li a.active, .sidebar ul li a:hover { background-color: #3b4a6b; color: #fff; }
        .sidebar ul li a i { margin-right: 10px; font-size: 16px; }
        .top-bar { position: fixed; top: 0; left: 270px; width: calc(100% - 270px); background: #fff; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,.05); transition: left .3s ease, width .3s ease; z-index: 999; }
        .top-bar.full-width { left: 0; width: 100%; }
        .top-bar .user-info { display: flex; align-items: center; gap: 10px; }
        .top-bar .user-info span { font-weight: 500; font-size: 14px; }
        .top-bar .controls { display: flex; align-items: center; gap: 15px; }
        .top-bar .hamburger { font-size: 20px; cursor: pointer; color: #4b5e82; }
        .top-bar .notifications { position: relative; }
        .top-bar .notifications i { font-size: 18px; cursor: pointer; color: #4b5e82; }
        .top-bar .notifications .badge { position: absolute; top: -5px; right: -5px; background-color: #e63946; color: #fff; font-size: 10px; padding: 2px 5px; border-radius: 50%; }
        .push-notification { position: fixed; top: 50px; right: 10px; padding: 8px 15px; border-radius: 8px; color: #fff; font-size: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.15); display: none; z-index: 1001; animation: slideInDown .5s ease forwards; }
        @keyframes slideInDown { from { transform: translateY(-100%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        .push-notification.important { background: #e63946; }
        .push-notification.normal { background: #2d6a4f; }
        .push-notification.medium { background: #f4a261; color: #1e2a44; }
        .main-content { margin-left: 270px; margin-top: 60px; padding: 20px; min-height: calc(100vh - 100px); transition: margin-left .3s ease; }
        .main-content.full-width { margin-left: 0; }
        .section { display: none; background: #fff; padding: 20px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.05); margin-bottom: 20px; }
        .section.active { display: block; }
        h2 { font-size: 20px; font-weight: 600; margin-bottom: 15px; position: relative; }
        h2::after { content: ''; position: absolute; bottom: -5px; left: 0; width: 30px; height: 2px; background: #4b5e82; }
        .card-container { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 20px; }
        .card { background: #fff; padding: 20px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.05); text-align: center; border-left: 4px solid #4b5e82; cursor: pointer; transition: transform .3s ease; }
        .card:hover { transform: translateY(-5px); }
        .card h3 { font-size: 16px; font-weight: 500; margin-bottom: 10px; }
        .card p { font-size: 24px; font-weight: 600; color: #4b5e82; }
        .form-group { margin-bottom: 15px; }
        .form-group label { display: block; font-weight: 500; margin-bottom: 5px; font-size: 14px; }
        .form-group input, .form-group select, .form-group textarea { width: 100%; padding: 10px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; }
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; background: #fff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,.05); }
        table th, table td { padding: 10px; text-align: left; font-size: 12px; }
        table th { background: #4b5e82; color: #fff; font-weight: 500; }
        table tr { transition: background .3s ease; }
        table tr:hover { background: #f9fafb; }
        table td { border-bottom: 1px solid #e5e7eb; }
        .btn { padding: 10px 15px; border: none; border-radius: 8px; cursor: pointer; font-size: 12px; font-weight: 500; transition: all .3s ease; display: inline-flex; align-items: center; gap: 5px; }
        .btn-primary { background: #4b5e82; color: #fff; }
        .btn-primary:hover { background: #3b4a6b; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,.1); }
        .btn-danger { background: #e63946; color: #fff; }
        .btn-danger:hover { background: #c53030; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,.1); }
        .btn i { font-size: 14px; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,.7); justify-content: center; align-items: center; z-index: 1000; }
        .modal-content { background: #fff; padding: 20px; border-radius: 12px; width: 90%; max-width: 500px; box-shadow: 0 6px 25px rgba(0,0,0,.15); }
        .error { color: #e63946; text-align: center; margin-bottom: 10px; font-size: 12px; }
        .message { color: #2d6a4f; text-align: center; margin-bottom: 10px; font-size: 12px; }
        footer { position: fixed; bottom: 0; left: 270px; width: calc(100% - 270px); background: #1e2a44; color: #d1d5db; padding: 10px 20px; text-align: center; font-size: 12px; transition: left .3s ease, width .3s ease; z-index: 998; }
        footer.full-width { left: 0; width: 100%; }
        footer span { margin: 0 5px; }
        @media (max-width: 768px) {
            .sidebar { width: 220px; }
            .main-content { margin-left: 220px; }
            .top-bar { left: 220px; width: calc(100% - 220px); }
            footer { left: 220px; width: calc(100% - 220px); }
        }
        @media (max-width: 480px) {
            .sidebar { width: 100%; height: auto; position: relative; transform: translateX(-100%); padding: 10px; }
            .sidebar.hidden { transform: translateX(-100%); }
            .sidebar.active { transform: translateX(0); }
            .top-bar { left: 0; width: 100%; padding: 10px; }
            .top-bar .user-info span { font-size: 12px; }
            .top-bar .hamburger { font-size: 18px; }
            .main-content { margin-left: 0; margin-top: 50px; padding: 10px; }
            h2 { font-size: 18px; }
            .card h3 { font-size: 14px; }
            .card p { font-size: 20px; }
            .form-group label { font-size: 12px; }
            .form-group input, .form-group select, .form-group textarea { font-size: 12px; padding: 8px; }
            .btn { font-size: 10px; padding: 8px 12px; }
            table th, table td { font-size: 10px; padding: 8px; }
            footer { font-size: 10px; padding: 8px; }
        }
    </style>
</head>
<body>
    <div class="top-bar">
        <div class="user-info">
            <i class="fas fa-bars hamburger" onclick="toggleSidebar()"></i>
            <span>Hi, Admin</span>
        </div>
        <div class="controls">
            <div class="notifications">
                <i class="fas fa-bell" onclick="showPushNotification('notifications')"></i>
                <span class="badge"><?php echo $conn->query("SELECT COUNT(*) FROM notification_db WHERE created_at > NOW() - INTERVAL 1 DAY")->fetchColumn(); ?></span>
                <?php
                $notifs = $conn->query("SELECT message FROM notification_db ORDER BY created_at DESC LIMIT 3");
                $i = 0;
                while ($row = $notifs->fetch(PDO::FETCH_ASSOC)) {
                    $class = ['important', 'normal', 'medium'][$i % 3];
                    echo "<div class='push-notification $class' id='push-$i'>{$row['message']}</div>";
                    $i++;
                }
                ?>
            </div>
            <a href="logout.php" class="btn btn-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>
    <div class="sidebar hidden">
        <div class="logo">PCCoER Admin</div>
        <div class="search-bar">
            <input type="text" id="searchInput" placeholder="Search..." onkeyup="searchData()">
        </div>
        <ul>
            <li><a href="#dashboard" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="#departments"><i class="fas fa-building"></i> Departments</a></li>
            <li><a href="#students"><i class="fas fa-user-graduate"></i> Students</a></li>
            <li><a href="#teachers"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
            <li><a href="#attendance"><i class="fas fa-calendar-check"></i> Attendance</a></li>
            <li><a href="#logs"><i class="fas fa-shield-alt"></i> Logs</a></li>
            <li><a href="#notifications"><i class="fas fa-bell"></i> Notifications</a></li>
            <li><a href="#access"><i class="fas fa-key"></i> Access Control</a></li>
            <li><a href="#reports"><i class="fas fa-chart-bar"></i> Reports</a></li>
        </ul>
    </div>
    <div class="main-content">
        <?php if ($error): ?><p class="error"><?php echo htmlspecialchars($error); ?></p><?php endif; ?>
        <?php if ($message): ?><p class="message"><?php echo htmlspecialchars($message); ?></p><?php endif; ?>
        <div id="dashboard" class="section active">
            <h2>Dashboard</h2>
            <p>Welcome to the PCCoER Admin Dashboard.</p>
            <div class="card-container">
                <div class="card"><h3>Total Students</h3><p><?php echo $conn->query("SELECT COUNT(*) FROM students_db")->fetchColumn(); ?></p></div>
                <div class="card"><h3>Total Teachers</h3><p><?php echo $conn->query("SELECT COUNT(*) FROM users_db WHERE role = 'Teacher'")->fetchColumn(); ?></p></div>
                <div class="card"><h3>Attendance Rate</h3><p><?php $total = $conn->query("SELECT COUNT(*) FROM attendance_db")->fetchColumn(); $present = $conn->query("SELECT COUNT(*) FROM attendance_db WHERE status = 'Present'")->fetchColumn(); echo $total ? round(($present / $total) * 100) : 0; ?>%</p></div>
                <div class="card"><h3>Total Departments</h3><p><?php echo $conn->query("SELECT COUNT(*) FROM departments_db")->fetchColumn(); ?></p></div>
            </div>
            <a href="download_db.php" class="btn btn-primary"><i class="fas fa-download"></i> Download Database</a>
        </div>
        <div id="departments" class="section">
            <h2>Departments</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="dept_name">Add Department</label>
                    <input type="text" id="dept_name" name="dept_name" required>
                </div>
                <button type="submit" name="add_dept" class="btn btn-primary"><i class="fas fa-plus"></i> Add</button>
            </form>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>ID</th><th>Name</th></tr></thead>
                    <tbody>
                        <?php foreach ($departments as $dept): ?>
                            <tr><td><?php echo $dept['id']; ?></td><td><?php echo htmlspecialchars($dept['name']); ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="students" class="section">
            <h2>Student Management</h2>
            <button class="btn btn-primary" onclick="openModal('addStudent')"><i class="fas fa-plus"></i> Add Student</button>
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="excel_upload">Upload Students (Excel: Email, Name, Dept, Division, PRN, Roll No)</label>
                    <input type="file" id="excel_upload" name="excel_upload" accept=".xlsx, .xls" required>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Upload</button>
            </form>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>ID</th><th>Email</th><th>Name</th><th>Department</th><th>Division</th><th>PRN</th><th>Roll No</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                            <tr><td><?php echo $student['id']; ?></td><td><?php echo htmlspecialchars($student['email']); ?></td><td><?php echo htmlspecialchars($student['name']); ?></td><td><?php echo htmlspecialchars($student['dept']); ?></td><td><?php echo htmlspecialchars($student['division']); ?></td><td><?php echo htmlspecialchars($student['prn']); ?></td><td><?php echo htmlspecialchars($student['roll_no']); ?></td><td><button class="btn btn-primary" onclick="editStudent(<?php echo $student['id']; ?>, '<?php echo $student['email']; ?>', '<?php echo $student['name']; ?>', '<?php echo $student['dept']; ?>', '<?php echo $student['division']; ?>', '<?php echo $student['prn']; ?>', '<?php echo $student['roll_no']; ?>')"><i class="fas fa-edit"></i> Edit</button><button class="btn btn-danger" onclick="deleteStudent(<?php echo $student['id']; ?>)"><i class="fas fa-trash"></i> Delete</button></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="teachers" class="section">
            <h2>Teacher Management</h2>
            <button class="btn btn-primary" onclick="openModal('addTeacher')"><i class="fas fa-plus"></i> Add Teacher</button>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>ID</th><th>Email</th><th>Name</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php foreach ($teachers as $teacher): ?>
                            <tr><td><?php echo $teacher['id']; ?></td><td><?php echo htmlspecialchars($teacher['email']); ?></td><td><?php echo htmlspecialchars($teacher['name']); ?></td><td><button class="btn btn-primary" onclick="editTeacher(<?php echo $teacher['id']; ?>, '<?php echo $teacher['email']; ?>', '<?php echo $teacher['name']; ?>')"><i class="fas fa-edit"></i> Edit</button><button class="btn btn-danger" onclick="deleteTeacher(<?php echo $teacher['id']; ?>)"><i class="fas fa-trash"></i> Delete</button></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="attendance" class="section">
            <h2>Attendance Management</h2>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>Date</th><th>Student ID</th><th>Status</th><th>Method</th></tr></thead>
                    <tbody>
                        <?php foreach ($attendance as $record): ?>
                            <tr><td><?php echo $record['date']; ?></td><td><?php echo $record['student_id']; ?></td><td><?php echo $record['status']; ?></td><td><?php echo $record['method']; ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="logs" class="section">
            <h2>System Logs</h2>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>Timestamp</th><th>User</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                            <tr><td><?php echo $log['timestamp']; ?></td><td><?php echo htmlspecialchars($log['email']); ?></td><td><?php echo htmlspecialchars($log['action']); ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="notifications" class="section">
            <h2>Notifications</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="notification">Send Notification</label>
                    <textarea id="notification" name="notification" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send</button>
            </form>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>Message</th><th>Date</th></tr></thead>
                    <tbody>
                        <?php foreach ($notifications as $notif): ?>
                            <tr><td><?php echo htmlspecialchars($notif['message']); ?></td><td><?php echo $notif['created_at']; ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="access" class="section">
            <h2>Access Control</h2>
            <button class="btn btn-primary" onclick="openModal('addAdmin')"><i class="fas fa-plus"></i> Add Admin</button>
            <div class="table-wrapper">
                <table>
                    <thead><tr><th>ID</th><th>Email</th><th>Name</th><th>Role</th><th>Actions</th></tr></thead>
                    <tbody>
                        <?php foreach ($admins as $admin): ?>
                            <tr><td><?php echo $admin['id']; ?></td><td><?php echo htmlspecialchars($admin['email']); ?></td><td><?php echo htmlspecialchars($admin['name']); ?></td><td><?php echo $admin['role']; ?></td><td><button class="btn btn-danger" onclick="deleteAdmin(<?php echo $admin['id']; ?>)"><i class="fas fa-trash"></i> Delete</button></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="reports" class="section">
            <h2>Reports</h2>
            <button class="btn btn-primary" onclick="generateReport()"><i class="fas fa-file-alt"></i> Generate Report</button>
            <button class="btn btn-primary" onclick="sendToParents()"><i class="fas fa-paper-plane"></i> Send to Parents</button>
        </div>
    </div>
    <footer>
        <span>All Rights Reserved © Designed and Developed by Yash Shastri and Team</span> | 
        <span>©PCCoER Attendance System Version v1.5 ®</span>
    </footer>
    <div id="addStudent" class="modal">
        <div class="modal-content">
            <h2>Add Student</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" required>
                </div>
                <div class="form-group">
                    <label for="department">Department</label>
                    <select name="department" required>
                        <option value="">Select Department</option>
                        <?php foreach ($departments as $dept): ?>
                            <option value="<?php echo $dept['name']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="division">Division</label>
                    <input type="text" name="division" required>
                </div>
                <div class="form-group">
                    <label for="prn">PRN</label>
                    <input type="text" name="prn" required>
                </div>
                <div class="form-group">
                    <label for="roll_no">Roll Number</label>
                    <input type="text" name="roll_no" required>
                </div>
                <button type="submit" name="add_student" class="btn btn-primary"><i class="fas fa-plus"></i> Add</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('addStudent')"><i class="fas fa-times"></i> Cancel</button>
            </form>
        </div>
    </div>
    <div id="editStudent" class="modal">
        <div class="modal-content">
            <h2>Edit Student</h2>
            <form method="POST">
                <input type="hidden" name="id" id="editStudentId">
                <div class="form-group">
                    <label for="editStudentEmail">Email</label>
                    <input type="email" name="email" id="editStudentEmail" required>
                </div>
                <div class="form-group">
                    <label for="editStudentName">Name</label>
                    <input type="text" name="name" id="editStudentName" required>
                </div>
                <div class="form-group">
                    <label for="editStudentDept">Department</label>
                    <select name="department" id="editStudentDept" required>
                        <?php foreach ($departments as $dept): ?>
                            <option value="<?php echo $dept['name']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="editStudentDivision">Division</label>
                    <input type="text" name="division" id="editStudentDivision" required>
                </div>
                <div class="form-group">
                    <label for="editStudentPRN">PRN</label>
                    <input type="text" name="prn" id="editStudentPRN" required>
                </div>
                <div class="form-group">
                    <label for="editStudentRollNo">Roll Number</label>
                    <input type="text" name="roll_no" id="editStudentRollNo" required>
                </div>
                <button type="submit" name="edit_student" class="btn btn-primary"><i class="fas fa-save"></i> Save</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('editStudent')"><i class="fas fa-times"></i> Cancel</button>
            </form>
        </div>
    </div>
    <div id="addTeacher" class="modal">
        <div class="modal-content">
            <h2>Add Teacher</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" required>
                </div>
                <div class="form-group">
                    <label for="department">Department</label>
                    <select name="department" required>
                        <option value="">Select Department</option>
                        <?php foreach ($departments as $dept): ?>
                            <option value="<?php echo $dept['name']; ?>"><?php echo htmlspecialchars($dept['name']); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" name="add_teacher" class="btn btn-primary"><i class="fas fa-plus"></i> Add</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('addTeacher')"><i class="fas fa-times"></i> Cancel</button>
            </form>
        </div>
    </div>
    <div id="editTeacher" class="modal">
        <div class="modal-content">
            <h2>Edit Teacher</h2>
            <form method="POST">
                <input type="hidden" name="id" id="editTeacherId">
                <div class="form-group">
                    <label for="editTeacherEmail">Email</label>
                    <input type="email" name="email" id="editTeacherEmail" required>
                </div>
                <div class="form-group">
                    <label for="editTeacherName">Name</label>
                    <input type="text" name="name" id="editTeacherName" required>
                </div>
                <button type="submit" name="edit_teacher" class="btn btn-primary"><i class="fas fa-save"></i> Save</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('editTeacher')"><i class="fas fa-times"></i> Cancel</button>
            </form>
        </div>
    </div>
    <div id="addAdmin" class="modal">
        <div class="modal-content">
            <h2>Add Admin</h2>
            <form method="POST">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input type="text" name="name" required>
                </div>
                <div class="form-group">
                    <label for="role">Role</label>
                    <select name="role" required>
                        <option value="">Select Role</option>
                        <option value="Admin">Admin</option>
                        <option value="Partial Admin">Partial Admin</option>
                    </select>
                </div>
                <button type="submit" name="add_admin" class="btn btn-primary"><i class="fas fa-plus"></i> Add</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('addAdmin')"><i class="fas fa-times"></i> Cancel</button>
            </form>
        </div>
    </div>
    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            sidebar.classList.toggle('hidden');
            sidebar.classList.toggle('active');
            const topBar = document.querySelector('.top-bar');
            const mainContent = document.querySelector('.main-content');
            const footer = document.querySelector('footer');
            topBar.classList.toggle('full-width');
            mainContent.classList.toggle('full-width');
            footer.classList.toggle('full-width');
        }

        document.querySelectorAll('.sidebar a').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const target = this.getAttribute('href').substring(1);
                document.querySelectorAll('.section').forEach(section => section.classList.remove('active'));
                document.getElementById(target).classList.add('active');
                document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
                this.classList.add('active');
                if (window.innerWidth <= 480) toggleSidebar();
            });
        });

        function openModal(id) {
            document.getElementById(id).style.display = 'flex';
        }

        function closeModal(id) {
            document.getElementById(id).style.display = 'none';
        }

        function editStudent(id, email, name, dept, division, prn, rollNo) {
            document.getElementById('editStudentId').value = id;
            document.getElementById('editStudentEmail').value = email;
            document.getElementById('editStudentName').value = name;
            document.getElementById('editStudentDept').value = dept;
            document.getElementById('editStudentDivision').value = division;
            document.getElementById('editStudentPRN').value = prn;
            document.getElementById('editStudentRollNo').value = rollNo;
            openModal('editStudent');
        }

        function deleteStudent(id) {
            if (confirm('Delete student ' + id + '?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `<input type="hidden" name="id" value="${id}"><input type="hidden" name="delete_student" value="1">`;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function editTeacher(id, email, name) {
            document.getElementById('editTeacherId').value = id;
            document.getElementById('editTeacherEmail').value = email;
            document.getElementById('editTeacherName').value = name;
            openModal('editTeacher');
        }

        function deleteTeacher(id) {
            if (confirm('Delete teacher ' + id + '?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `<input type="hidden" name="id" value="${id}"><input type="hidden" name="delete_teacher" value="1">`;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function deleteAdmin(id) {
            if (confirm('Remove admin ' + id + '?')) {
                const form = document.createElement('form');
                form.method = 'POST';
                form.innerHTML = `<input type="hidden" name="id" value="${id}"><input type="hidden" name="delete_admin" value="1">`;
                document.body.appendChild(form);
                form.submit();
            }
        }

        function generateReport() {
            alert('Report generation placeholder. Implement actual logic.');
        }

        function sendToParents() {
            alert('Sending to parents placeholder. Implement WhatsApp API.');
        }

        function showPushNotification(section) {
            if (section === 'notifications') {
                document.querySelectorAll('.push-notification').forEach((n, i) => {
                    setTimeout(() => {
                        n.style.display = 'block';
                        setTimeout(() => n.style.display = 'none', 3000);
                    }, i * 1000);
                });
            }
        }

        function searchData() {
            const input = document.getElementById('searchInput').value.toLowerCase();
            document.querySelectorAll('table tbody tr').forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(input) ? '' : 'none';
            });
        }
    </script>
</body>
</html>