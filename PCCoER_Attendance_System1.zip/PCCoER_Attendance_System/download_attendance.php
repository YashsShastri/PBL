<?php
require_once 'config.php';
require_once 'functions.php';
require 'vendor/autoload.php'; // PhpSpreadsheet
use PhpOffice\PhpSpreadsheet\Spreadsheet;

$division_id = (int)$_GET['division_id'];
$students = $conn->query("SELECT u.name, s.prn, s.roll_no, (SELECT COUNT(*) FROM attendance_db a WHERE a.student_id = s.id AND a.status = 'Present') AS present FROM students_db s JOIN users_db u ON s.user_id = u.id WHERE s.division_id = :division_id")->execute(['division_id' => $division_id])->fetchAll(PDO::FETCH_ASSOC);

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setCellValue('A1', 'Name')->setCellValue('B1', 'PRN')->setCellValue('C1', 'Roll No')->setCellValue('D1', 'Present Days');
$row = 2;
foreach ($students as $student) {
    $sheet->setCellValue("A$row", $student['name'])->setCellValue("B$row", $student['prn'])->setCellValue("C$row", $student['roll_no'])->setCellValue("D$row", $student['present']);
    $row++;
}

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="attendance_report.xlsx"');
$writer = new PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
$writer->save('php://output');
exit;