<?php
require_once '../config.php';
redirectIfNotLoggedIn();
if (getUserRole() !== 'Student') exit;

$output = shell_exec('python ../python/face_recognition.py ' . $_SESSION['user_id']);
if (trim($output) === 'Match') {
    $stmt = $conn->prepare("INSERT INTO attendance_db (student_id, date, status, method) VALUES ((SELECT id FROM students_db WHERE user_id = ?), CURDATE(), 'Present', 'Face')");
    $stmt->bind_param("i", $_SESSION['user_id']);
    $stmt->execute();
    logAction($_SESSION['user_id'], 'Marked attendance via Face');
    echo "Attendance marked via face recognition";
} else {
    echo "Face recognition failed";
}
?>