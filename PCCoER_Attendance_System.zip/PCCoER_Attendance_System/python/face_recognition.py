import cv2
import face_recognition
import sys
import os

user_id = sys.argv[1]
face_path = [f for f in os.listdir('faces') if f.startswith(f'SECOC64_2023')][0]  # Dummy match
image = face_recognition.load_image_file(f"faces/{face_path}")
known_encoding = face_recognition.face_encodings(image)[0]

cap = cv2.VideoCapture(0)
ret, frame = cap.read()
rgb_frame = frame[:, :, ::-1]
face_locations = face_recognition.face_locations(rgb_frame)
face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

for face_encoding in face_encodings:
    matches = face_recognition.compare_faces([known_encoding], face_encoding)
    if True in matches:
        print("Match")
        break
else:
    print("No match")
cap.release()