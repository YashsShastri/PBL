function toggleSidebar() {
    document.querySelector('.sidebar').classList.toggle('hidden');
    document.querySelector('.top-bar').classList.toggle('full-width');
    document.querySelector('.main-content').classList.toggle('full-width');
    document.querySelector('footer').classList.toggle('full-width');
}

document.querySelectorAll('.sidebar a').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        const target = this.getAttribute('href').substring(1);
        document.querySelectorAll('.section').forEach(section => section.classList.remove('active'));
        document.getElementById(target).classList.add('active');
        document.querySelectorAll('.sidebar a').forEach(a => a.classList.remove('active'));
        this.classList.add('active');
    });
});

function checkLocation() {
    navigator.geolocation.getCurrentPosition(
        (position) => {
            const lat = position.coords.latitude;
            const lon = position.coords.longitude;
            const pccoerLat = 18.6529; // Replace with actual
            const pccoerLon = 73.8471; // Replace with actual
            const distance = getDistance(lat, lon, pccoerLat, pccoerLon);
            const dot = document.getElementById('location-dot');
            const msg = document.getElementById('location-msg');
            if (distance < 0.5) {
                dot.classList.add('green');
                msg.textContent = 'You are inside campus';
            } else {
                dot.classList.add('red');
                msg.textContent = 'You are outside campus';
            }
        },
        () => {
            document.getElementById('location-msg').textContent = 'Location access denied';
            document.getElementById('location-dot').classList.add('red');
        }
    );
}

function getDistance(lat1, lon1, lat2, lon2) {
    const R = 6371;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
}