<?php
require_once 'functions.php';
redirectIfNotLoggedIn();
if (!$_SESSION['first_login']) {
    header('Location: ' . (getUserRole() === 'Admin' ? 'admin_dashboard.php' : (getUserRole() === 'Teacher' ? 'teacher_dashboard.php' : 'student_dashboard.php')));
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role = getUserRole();
    if ($role === 'Admin') {
        // Admin registration (minimal, as Admin might not need much additional data)
        $stmt = $conn->prepare("UPDATE users_db SET first_login = FALSE WHERE id = ?");
        $stmt->bind_param("i", $_SESSION['user_id']);
        $stmt->execute();
        logAction($_SESSION['user_id'], 'Completed Admin registration');
        header('Location: admin_dashboard.php');
        exit;
    } elseif ($role === 'Teacher') {
        $department = $_POST['department'];
        $teacher_role = $_POST['role'];
        $division = $_POST['division'] ?? null;
        if ($teacher_role === 'Class Teacher' && empty($division)) {
            $error = "Division is required for Class Teacher";
        } else {
            $stmt = $conn->prepare("INSERT INTO division_db (department_id, name) VALUES ((SELECT id FROM departments_db WHERE name = ?), ?)");
            if ($division) {
                $stmt->bind_param("ss", $department, $division);
                $stmt->execute();
            }
            $stmt = $conn->prepare("UPDATE users_db SET first_login = FALSE WHERE id = ?");
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            logAction($_SESSION['user_id'], "Completed Teacher registration: $department, $teacher_role" . ($division ? ", Division: $division" : ""));
            header('Location: teacher_dashboard.php');
            exit;
        }
    } elseif ($role === 'Student') {
        $division = $_POST['division'];
        $roll_no = $_POST['roll_no'];
        $prn = $_POST['prn'];
        $face_image = $_FILES['face_image'];
        $target_dir = "python/faces/";
        $face_data = "SECOC64_2023-" . substr($_SESSION['email'], strpos($_SESSION['email'], '_') + 1, -10) . "-" . $division . "-" . $roll_no . ".jpg";
        
        if (move_uploaded_file($face_image["tmp_name"], $target_dir . $face_data)) {
            $stmt = $conn->prepare("INSERT INTO students_db (user_id, division_id, prn, roll_no, face_data) VALUES (?, (SELECT id FROM division_db WHERE name = ? LIMIT 1), ?, ?, ?)");
            $stmt->bind_param("issss", $_SESSION['user_id'], $division, $prn, $roll_no, $face_data);
            $stmt->execute();
            $stmt = $conn->prepare("UPDATE users_db SET first_login = FALSE WHERE id = ?");
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            logAction($_SESSION['user_id'], "Completed Student registration: PRN $prn, Roll No $roll_no, Division $division");
            header('Location: student_dashboard.php');
            exit;
        } else {
            $error = "Failed to upload face image";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>First-Time Registration</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .register-container { max-width: 500px; margin: 100px auto; padding: 30px; background: #fff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        input, select, textarea { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #e5e7eb; border-radius: 8px; }
        .btn { width: 100%; padding: 12px 20px; background: #4b5e82; color: #fff; border: none; border-radius: 8px; cursor: pointer; }
        .btn:hover { background: #3b4a6b; }
        .error { color: #e63946; }
    </style>
</head>
<body>
    <div class="register-container">
        <h2>First-Time Registration</h2>
        <?php if ($error) echo "<p class='error'>$error</p>"; ?>
        <form method="POST" enctype="multipart/form-data">
            <?php if (getUserRole() === 'Admin') { ?>
                <p>Welcome, Admin! Click below to complete registration.</p>
                <button type="submit" class="btn">Complete Registration</button>
            <?php } elseif (getUserRole() === 'Teacher') { ?>
                <select name="department" required>
                    <option value="">Select Department</option>
                    <option value="CS">CS</option>
                    <option value="IT">IT</option>
                    <option value="ENTC">ENTC</option>
                    <option value="Civil">Civil</option>
                    <option value="Mech">Mech</option>
                </select>
                <select name="role" required onchange="toggleDivision(this)">
                    <option value="">Select Role</option>
                    <option value="HOD">HOD</option>
                    <option value="Assistant Professor">Assistant Professor</option>
                    <option value="Professor">Professor</option>
                    <option value="Class Teacher">Class Teacher</option>
                </select>
                <input type="text" name="division" id="division" placeholder="Division (e.g., A)" style="display: none;">
                <button type="submit" class="btn">Register</button>
            <?php } elseif (getUserRole() === 'Student') { ?>
                <input type="text" name="division" placeholder="Division (e.g., A)" required>
                <input type="text" name="roll_no" placeholder="Roll Number" required>
                <input type="text" name="prn" placeholder="PRN Number" required>
                <input type="file" name="face_image" accept="image/*" required>
                <button type="submit" class="btn">Register</button>
            <?php } ?>
        </form>
    </div>

    <script>
        function toggleDivision(select) {
            const divisionInput = document.getElementById('division');
            if (select.value === 'Class Teacher') {
                divisionInput.style.display = 'block';
                divisionInput.required = true;
            } else {
                divisionInput.style.display = 'none';
                divisionInput.required = false;
            }
        }
    </script>
</body>
</html>