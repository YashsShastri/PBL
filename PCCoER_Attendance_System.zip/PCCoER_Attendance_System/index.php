<?php require_once 'config.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PCCoER Attendance System</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        body { font-family: 'Poppins', sans-serif; background: #f5f7fa; color: #1e2a44; }
        .container { text-align: center; padding: 50px; }
        .logo { width: 150px; margin-bottom: 20px; }
        .announcements { margin: 20px 0; }
        .scrolling-notifications { background: #fff; padding: 10px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); overflow: hidden; white-space: nowrap; }
        .scrolling-text { display: inline-block; animation: scroll 20s linear infinite; }
        @keyframes scroll { 0% { transform: translateX(100%); } 100% { transform: translateX(-100%); } }
        .btn { padding: 12px 20px; background: #4b5e82; color: #fff; border: none; border-radius: 8px; cursor: pointer; }
        .btn:hover { background: #3b4a6b; }
    </style>
</head>
<body>
    <div class="container">
        <img src="assets/images/pccoer_logo.png" alt="PCCoER Logo" class="logo">
        <h1>PCCoER Attendance System</h1>
        <div class="announcements">
            <p>Welcome to PCCoER! Check your attendance and schedules here.</p>
        </div>
        <div class="scrolling-notifications">
            <div class="scrolling-text">
                <?php
                $result = $conn->query("SELECT message FROM notification_db ORDER BY created_at DESC");
                while ($row = $result->fetch_assoc()) {
                    echo htmlspecialchars($row['message']) . " | ";
                }
                ?>
            </div>
        </div>
        <a href="login.php"><button class="btn">Login</button></a>
    </div>
</body>
</html>