<?php
require_once 'functions.php';
if (isLoggedIn()) {
    logAction($_SESSION['user_id'], 'Logged out');
    session_destroy();
}
header('Location: index.php');
exit;
?> 
