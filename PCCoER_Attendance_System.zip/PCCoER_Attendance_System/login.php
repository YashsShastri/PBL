<?php
// Ensure functions.php is included
if (file_exists('functions.php')) {
    require_once 'functions.php';
} else {
    die("Error: functions.php not found in " . __DIR__);
}

// Check if user is already logged in
if (isLoggedIn()) {
    if ($_SESSION['first_login']) {
        header('Location: register.php');
        exit;
    }
    header('Location: ' . (getUserRole() === 'Admin' ? 'admin_dashboard.php' : (getUserRole() === 'Teacher' ? 'teacher_dashboard.php' : 'student_dashboard.php')));
    exit;
}

// Handle login form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $stmt = $conn->prepare("SELECT id, password, role, first_login FROM users_db WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        if ($password === $row['password']) { // Replace with password_verify() in production
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['role'] = $row['role'];
            $_SESSION['first_login'] = $row['first_login'];
            logAction($row['id'], 'Logged in');
            if ($row['first_login']) {
                header('Location: register.php');
            } else {
                header('Location: ' . ($row['role'] === 'Admin' ? 'admin_dashboard.php' : ($row['role'] === 'Teacher' ? 'teacher_dashboard.php' : 'student_dashboard.php')));
            }
            exit;
        } else {
            $error = "Invalid password";
        }
    } else {
        $error = "User not found";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .login-container { max-width: 400px; margin: 100px auto; padding: 30px; background: #fff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        input { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #e5e7eb; border-radius: 8px; }
        .btn { width: 100%; padding: 12px 20px; background: #4b5e82; color: #fff; border: none; border-radius: 8px; cursor: pointer; }
        .btn:hover { background: #3b4a6b; }
        .error { color: #e63946; }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        <form method="POST">
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit" class="btn">Login</button>
        </form>
    </div>
</body>
</html>