<?php
// Start session and connect to database
session_start();
$conn = mysqli_connect('localhost', 'root', '', 'attendance_system_db');
if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>