<?php
require_once 'functions.php';
redirectIfNotLoggedIn();
if (getUserRole() !== 'Admin') {
    header('Location: index.php');
    exit;
}
if ($_SESSION['first_login']) {
    header('Location: register.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PCCoER Admin Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background-color: #f5f7fa; color: #1e2a44; line-height: 1.6; overflow-x: hidden; }
        .sidebar { position: fixed; top: 0; left: 0; width: 270px; height: 100%; background: linear-gradient(180deg, #1e2a44 0%, #172038 100%); color: #d1d5db; padding: 30px; transition: transform 0.3s ease; box-shadow: 2px 0 15px rgba(0,0,0,0.05); z-index: 1000; }
        .sidebar.hidden { transform: translateX(-270px); }
        .sidebar .logo { font-size: 26px; font-weight: 600; margin-bottom: 50px; text-align: center; color: #ffffff; letter-spacing: 1px; }
        .sidebar ul { list-style: none; }
        .sidebar ul li { margin: 20px 0; }
        .sidebar ul li a { color: #d1d5db; text-decoration: none; font-size: 16px; font-weight: 400; display: flex; align-items: center; padding: 12px 20px; border-radius: 8px; transition: all 0.3s ease; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background-color: #3b4a6b; color: #ffffff; }
        .sidebar ul li a i { margin-right: 15px; font-size: 18px; }
        .top-bar { position: fixed; top: 0; left: 270px; width: calc(100% - 270px); background: #ffffff; padding: 20px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,0.05); transition: left 0.3s ease, width 0.3s ease; z-index: 999; }
        .top-bar.full-width { left: 0; width: 100%; }
        .top-bar .user-info { display: flex; align-items: center; gap: 15px; }
        .top-bar .user-info span { font-weight: 500; font-size: 16px; color: #1e2a44; }
        .top-bar .controls { display: flex; align-items: center; gap: 20px; }
        .top-bar .hamburger { font-size: 24px; cursor: pointer; color: #4b5e82; }
        .main-content { margin-left: 270px; margin-top: 70px; padding: 30px; min-height: calc(100vh - 120px); transition: margin-left 0.3s ease; }
        .main-content.full-width { margin-left: 0; }
        .section { display: none; background: #ffffff; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 30px; }
        .section.active { display: block; }
        h2 { color: #1e2a44; font-size: 24px; font-weight: 600; margin-bottom: 25px; position: relative; }
        h2::after { content: ''; position: absolute; bottom: -5px; left: 0; width: 40px; height: 3px; background: #4b5e82; border-radius: 2px; }
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 25px; background: #ffffff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        table th, table td { padding: 15px; text-align: left; }
        table th { background: #4b5e82; color: #ffffff; font-weight: 500; }
        table tr { transition: background 0.3s ease; }
        table tr:hover { background: #f9fafb; }
        table td { border-bottom: 1px solid #e5e7eb; }
        .btn { padding: 12px 20px; border: none; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 500; transition: all 0.3s ease; display: inline-flex; align-items: center; gap: 8px; }
        .btn-primary { background: #4b5e82; color: #ffffff; }
        .btn-primary:hover { background: #3b4a6b; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .btn-danger { background: #e63946; color: #ffffff; }
        .btn-danger:hover { background: #c53030; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .btn i { font-size: 16px; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); justify-content: center; align-items: center; z-index: 1000; }
        .modal-content { background: #ffffff; padding: 30px; border-radius: 12px; width: 500px; max-width: 90%; box-shadow: 0 6px 25px rgba(0,0,0,0.15); }
        .modal-content h2 { margin-bottom: 25px; }
        .modal-content input, .modal-content select, .modal-content textarea { width: 100%; padding: 12px; margin-bottom: 20px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; transition: border-color 0.3s ease; }
        .modal-content input:focus, .modal-content select:focus, .modal-content textarea:focus { border-color: #4b5e82; outline: none; box-shadow: 0 0 5px rgba(75,94,130,0.2); }
        .modal-content .btn { margin-right: 15px; }
        footer { position: fixed; bottom: 0; left: 270px; width: calc(100% - 270px); background: #1e2a44; color: #d1d5db; padding: 15px 30px; text-align: center; font-size: 14px; font-weight: 400; transition: left 0.3s ease, width 0.3s ease; z-index: 998; }
        footer.full-width { left: 0; width: 100%; }
        footer span { margin: 0 10px; }
        @media (max-width: 768px) { .sidebar { width: 220px; } .main-content { margin-left: 220px; } .top-bar { left: 220px; width: calc(100% - 220px); } footer { left: 220px; width: calc(100% - 220px); } }
        @media (max-width: 480px) { .sidebar { width: 270px; transform: translateX(-270px); } .main-content { margin-left: 0; margin-top: 70px; } .top-bar { left: 0; width: 100%; } footer { left: 0; width: 100%; } .sidebar.hidden { transform: translateX(-270px); } }
    </style>
</head>
<body>
    <div class="top-bar">
        <div class="user-info">
            <i class="fas fa-bars hamburger" onclick="toggleSidebar()"></i>
            <span>Admin</span>
        </div>
        <div class="controls">
            <a href="logout.php" class="btn btn-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>
    <div class="sidebar">
        <div class="logo">PCCoER Admin</div>
        <ul>
            <li><a href="#dashboard" class="active"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
            <li><a href="#departments"><i class="fas fa-building"></i> Departments</a></li>
            <li><a href="#students"><i class="fas fa-user-graduate"></i> Students</a></li>
            <li><a href="#teachers"><i class="fas fa-chalkboard-teacher"></i> Teachers</a></li>
            <li><a href="#attendance"><i class="fas fa-calendar-check"></i> Attendance</a></li>
            <li><a href="#notifications"><i class="fas fa-bell"></i> Notifications</a></li>
            <li><a href="#logs"><i class="fas fa-shield-alt"></i> Logs</a></li>
            <li><a href="#reports"><i class="fas fa-chart-bar"></i> Reports</a></li>
        </ul>
    </div>
    <div class="main-content">
        <div id="dashboard" class="section active">
            <h2>Dashboard</h2>
            <button class="btn btn-primary" onclick="downloadDatabase()"><i class="fas fa-download"></i> Download Database</button>
            <div class="table-wrapper" style="margin-top: 25px;">
                <table>
                    <thead>
                        <tr>
                            <th>Total Users</th>
                            <th>Total Departments</th>
                            <th>Total Students</th>
                            <th>Total Teachers</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo $conn->query("SELECT COUNT(*) FROM users_db")->fetch_row()[0]; ?></td>
                            <td><?php echo $conn->query("SELECT COUNT(*) FROM departments_db")->fetch_row()[0]; ?></td>
                            <td><?php echo $conn->query("SELECT COUNT(*) FROM students_db")->fetch_row()[0]; ?></td>
                            <td><?php echo $conn->query("SELECT COUNT(*) FROM users_db WHERE role = 'Teacher'")->fetch_row()[0]; ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="departments" class="section">
            <h2>Departments</h2>
            <button class="btn btn-primary" onclick="openModal('addDepartment')"><i class="fas fa-plus"></i> Add Department</button>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = $conn->query("SELECT * FROM departments_db");
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['id']}</td><td>{$row['name']}</td><td><button class='btn btn-danger'><i class='fas fa-trash'></i> Delete</button></td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="students" class="section">
            <h2>Students</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Email</th>
                            <th>PRN</th>
                            <th>Roll No</th>
                            <th>Division</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = $conn->query("SELECT u.email, s.id, s.prn, s.roll_no, d.name AS division FROM students_db s JOIN users_db u ON s.user_id = u.id JOIN division_db d ON s.division_id = d.id");
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['id']}</td><td>{$row['email']}</td><td>{$row['prn']}</td><td>{$row['roll_no']}</td><td>{$row['division']}</td><td><button class='btn btn-danger'><i class='fas fa-trash'></i> Delete</button></td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="teachers" class="section">
            <h2>Teachers</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Email</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = $conn->query("SELECT id, email FROM users_db WHERE role = 'Teacher'");
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['id']}</td><td>{$row['email']}</td><td><button class='btn btn-danger'><i class='fas fa-trash'></i> Delete</button></td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="attendance" class="section">
            <h2>Attendance</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Method</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = $conn->query("SELECT * FROM attendance_db");
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['student_id']}</td><td>{$row['date']}</td><td>{$row['status']}</td><td>{$row['method']}</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="notifications" class="section">
            <h2>Notifications</h2>
            <form method="POST">
                <textarea name="notification" placeholder="Enter notification" required></textarea>
                <button type="submit" class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send</button>
            </form>
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['notification'])) {
                $stmt = $conn->prepare("INSERT INTO notification_db (message) VALUES (?)");
                $stmt->bind_param("s", $_POST['notification']);
                $stmt->execute();
                logAction($_SESSION['user_id'], 'Sent notification: ' . $_POST['notification']);
            }
            ?>
            <div class="table-wrapper" style="margin-top: 25px;">
                <table>
                    <thead>
                        <tr>
                            <th>Message</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = $conn->query("SELECT * FROM notification_db ORDER BY created_at DESC");
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['message']}</td><td>{$row['created_at']}</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="logs" class="section">
            <h2>System Logs</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Action</th>
                            <th>Timestamp</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = $conn->query("SELECT u.email, l.action, l.timestamp FROM system_log_db l JOIN users_db u ON l.user_id = u.id ORDER BY l.timestamp DESC");
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['email']}</td><td>{$row['action']}</td><td>{$row['timestamp']}</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="reports" class="section">
            <h2>Reports</h2>
            <button class="btn btn-primary" onclick="sendToParents()"><i class="fas fa-paper-plane"></i> Send to Parents</button>
        </div>
    </div>
    <footer>
        <span>All Rights Reserved to Yash Shastri and Team</span> | 
        <span>PCCoER Attendance System Version v1.5</span>
    </footer>
    <div id="addDepartment" class="modal">
        <div class="modal-content">
            <h2>Add Department</h2>
            <form method="POST" action="admin_dashboard.php">
                <input type="text" name="dept_name" placeholder="Department Name" required>
                <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('addDepartment')"><i class="fas fa-times"></i> Cancel</button>
            </form>
            <?php
            if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['dept_name'])) {
                $stmt = $conn->prepare("INSERT INTO departments_db (name) VALUES (?)");
                $stmt->bind_param("s", $_POST['dept_name']);
                $stmt->execute();
                logAction($_SESSION['user_id'], 'Added department: ' . $_POST['dept_name']);
            }
            ?>
        </div>
    </div>
    <script src="assets/js/scripts.js"></script>
    <script>
        function downloadDatabase() {
            window.location.href = 'download_db.php';
        }
        function sendToParents() {
            alert('Reports sent to parents via WhatsApp');
        }
        function openModal(id) {
            document.getElementById(id).style.display = 'flex';
        }
        function closeModal(id) {
            document.getElementById(id).style.display = 'none';
        }
    </script>
</body>
</html>