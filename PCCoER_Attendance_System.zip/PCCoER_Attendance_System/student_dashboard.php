<?php
require_once 'functions.php';
redirectIfNotLoggedIn();
if (getUserRole() !== 'Student') {
    header('Location: index.php');
    exit;
}
if ($_SESSION['first_login'] && $_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: register.php');
    exit;
}
if (isset($_POST['qr_data'])) {
    $stmt = $conn->prepare("SELECT token, expiry FROM qr_tokens WHERE token = ?");
    $stmt->bind_param("s", $_POST['qr_data']);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        if (strtotime($row['expiry']) > time()) {
            $stmt = $conn->prepare("INSERT INTO attendance_db (student_id, date, status, method) VALUES ((SELECT id FROM students_db WHERE user_id = ?), CURDATE(), 'Present', 'QR')");
            $stmt->bind_param("i", $_SESSION['user_id']);
            $stmt->execute();
            logAction($_SESSION['user_id'], 'Marked attendance via QR: ' . $_POST['qr_data']);
            $success = "Attendance marked successfully";
        } else {
            $error = "QR code has expired";
        }
    } else {
        $error = "Invalid QR code";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PCCoER Student Dashboard</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Poppins', sans-serif; background-color: #f5f7fa; color: #1e2a44; line-height: 1.6; overflow-x: hidden; }
        .sidebar { position: fixed; top: 0; left: 0; width: 270px; height: 100%; background: linear-gradient(180deg, #1e2a44 0%, #172038 100%); color: #d1d5db; padding: 30px; transition: transform 0.3s ease; box-shadow: 2px 0 15px rgba(0,0,0,0.05); z-index: 1000; }
        .sidebar.hidden { transform: translateX(-270px); }
        .sidebar .logo { font-size: 26px; font-weight: 600; margin-bottom: 50px; text-align: center; color: #ffffff; letter-spacing: 1px; }
        .sidebar ul { list-style: none; }
        .sidebar ul li { margin: 20px 0; }
        .sidebar ul li a { color: #d1d5db; text-decoration: none; font-size: 16px; font-weight: 400; display: flex; align-items: center; padding: 12px 20px; border-radius: 8px; transition: all 0.3s ease; }
        .sidebar ul li a:hover, .sidebar ul li a.active { background-color: #3b4a6b; color: #ffffff; }
        .sidebar ul li a i { margin-right: 15px; font-size: 18px; }
        .top-bar { position: fixed; top: 0; left: 270px; width: calc(100% - 270px); background: #ffffff; padding: 20px 30px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 10px rgba(0,0,0,0.05); transition: left 0.3s ease, width 0.3s ease; z-index: 999; }
        .top-bar.full-width { left: 0; width: 100%; }
        .top-bar .user-info { display: flex; align-items: center; gap: 15px; }
        .top-bar .user-info span { font-weight: 500; font-size: 16px; color: #1e2a44; }
        .top-bar .controls { display: flex; align-items: center; gap: 20px; }
        .top-bar .hamburger { font-size: 24px; cursor: pointer; color: #4b5e82; }
        .main-content { margin-left: 270px; margin-top: 70px; padding: 30px; min-height: calc(100vh - 120px); transition: margin-left 0.3s ease; }
        .main-content.full-width { margin-left: 0; }
        .section { display: none; background: #ffffff; padding: 30px; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 30px; }
        .section.active { display: block; }
        h2 { color: #1e2a44; font-size: 24px; font-weight: 600; margin-bottom: 25px; position: relative; }
        h2::after { content: ''; position: absolute; bottom: -5px; left: 0; width: 40px; height: 3px; background: #4b5e82; border-radius: 2px; }
        .table-wrapper { overflow-x: auto; }
        table { width: 100%; border-collapse: collapse; margin-top: 25px; background: #ffffff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
        table th, table td { padding: 15px; text-align: left; }
        table th { background: #4b5e82; color: #ffffff; font-weight: 500; }
        table tr { transition: background 0.3s ease; }
        table tr:hover { background: #f9fafb; }
        table td { border-bottom: 1px solid #e5e7eb; }
        .btn { padding: 12px 20px; border: none; border-radius: 8px; cursor: pointer; font-size: 14px; font-weight: 500; transition: all 0.3s ease; display: inline-flex; align-items: center; gap: 8px; }
        .btn-primary { background: #4b5e82; color: #ffffff; }
        .btn-primary:hover { background: #3b4a6b; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .btn-danger { background: #e63946; color: #ffffff; }
        .btn-danger:hover { background: #c53030; transform: translateY(-2px); box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .btn i { font-size: 16px; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); justify-content: center; align-items: center; z-index: 1000; }
        .modal-content { background: #ffffff; padding: 30px; border-radius: 12px; width: 500px; max-width: 90%; box-shadow: 0 6px 25px rgba(0,0,0,0.15); }
        .modal-content h2 { margin-bottom: 25px; }
        .modal-content input, .modal-content select, .modal-content textarea { width: 100%; padding: 12px; margin-bottom: 20px; border: 1px solid #e5e7eb; border-radius: 8px; font-size: 14px; transition: border-color 0.3s ease; }
        .modal-content input:focus, .modal-content select:focus, .modal-content textarea:focus { border-color: #4b5e82; outline: none; box-shadow: 0 0 5px rgba(75,94,130,0.2); }
        .modal-content .btn { margin-right: 15px; }
        footer { position: fixed; bottom: 0; left: 270px; width: calc(100% - 270px); background: #1e2a44; color: #d1d5db; padding: 15px 30px; text-align: center; font-size: 14px; font-weight: 400; transition: left 0.3s ease, width 0.3s ease; z-index: 998; }
        footer.full-width { left: 0; width: 100%; }
        footer span { margin: 0 10px; }
        .location-box { width: 100%; height: 200px; background: #ffffff; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); position: relative; margin-top: 20px; display: flex; justify-content: center; align-items: center; flex-direction: column; }
        .dot { width: 20px; height: 20px; border-radius: 50%; animation: blink 1s infinite; }
        .dot.green { background: #2d6a4f; }
        .dot.red { background: #e63946; }
        @keyframes blink { 0% { opacity: 1; } 50% { opacity: 0.3; } 100% { opacity: 1; } }
        .location-msg { margin-top: 10px; font-size: 16px; font-weight: 500; }
        .success { color: #2d6a4f; }
        .error { color: #e63946; }
        @media (max-width: 768px) { .sidebar { width: 220px; } .main-content { margin-left: 220px; } .top-bar { left: 220px; width: calc(100% - 220px); } footer { left: 220px; width: calc(100% - 220px); } }
        @media (max-width: 480px) { .sidebar { width: 270px; transform: translateX(-270px); } .main-content { margin-left: 0; margin-top: 70px; } .top-bar { left: 0; width: 100%; } footer { left: 0; width: 100%; } .sidebar.hidden { transform: translateX(-270px); } }
    </style>
</head>
<body>
    <div class="top-bar">
        <div class="user-info">
            <i class="fas fa-bars hamburger" onclick="toggleSidebar()"></i>
            <span>Yash</span>
        </div>
        <div class="controls">
            <a href="logout.php" class="btn btn-danger"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>
    <div class="sidebar">
        <div class="logo">PCCoER Student</div>
        <ul>
            <li><a href="#attendance" class="active"><i class="fas fa-calendar-check"></i> Attendance</a></li>
            <li><a href="#schedule"><i class="fas fa-clock"></i> Schedule</a></li>
            <li><a href="#notifications"><i class="fas fa-bell"></i> Notifications</a></li>
            <li><a href="#doubts"><i class="fas fa-question-circle"></i> Doubts</a></li>
        </ul>
    </div>
    <div class="main-content">
        <div id="attendance" class="section active">
            <h2>Attendance System</h2>
            <div class="location-box">
                <div id="location-dot" class="dot"></div>
                <span id="location-msg" class="location-msg">Checking location...</span>
            </div>
            <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
            <form method="POST" onsubmit="scanQRCode(event)" style="margin-top: 20px;">
                <input type="text" name="qr_data" placeholder="Enter QR Data" required>
                <button type="submit" class="btn btn-primary"><i class="fas fa-qrcode"></i> Scan QR Code</button>
            </form>
            <button class="btn btn-primary" onclick="faceRecognition()" style="margin-top: 20px;"><i class="fas fa-camera"></i> Face Recognition</button>
            <div class="table-wrapper" style="margin-top: 25px;">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Method</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = $conn->query("SELECT date, status, method FROM attendance_db WHERE student_id = (SELECT id FROM students_db WHERE user_id = {$_SESSION['user_id']})");
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['date']}</td><td>{$row['status']}</td><td>{$row['method']}</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="schedule" class="section">
            <h2>Class Schedule</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Class</th>
                            <th>Room</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>2023-10-02</td>
                            <td>10:00 AM</td>
                            <td>CS101</td>
                            <td>Room 101</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="notifications" class="section">
            <h2>Notifications</h2>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Message</th>
                            <th>Created At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $result = $conn->query("SELECT message, created_at FROM notification_db ORDER BY created_at DESC");
                        while ($row = $result->fetch_assoc()) {
                            echo "<tr><td>{$row['message']}</td><td>{$row['created_at']}</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div id="doubts" class="section">
            <h2>Doubt System</h2>
            <button class="btn btn-primary" onclick="openModal('submitDoubt')"><i class="fas fa-question"></i> Submit Doubt</button>
            <div class="table-wrapper" style="margin-top: 20px;">
                <table>
                    <thead>
                        <tr>
                            <th>Query</th>
                            <th>Date</th>
                            <th>Reply</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>What is recursion?</td>
                            <td>2023-10-01</td>
                            <td>Awaiting reply</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <footer>
        <span>All Rights Reserved to Yash Shastri and Team</span> | 
        <span>PCCoER Attendance System Version v1.5</span>
    </footer>
    <div id="submitDoubt" class="modal">
        <div class="modal-content">
            <h2>Submit Doubt</h2>
            <form onsubmit="submitDoubt(event); closeModal('submitDoubt'); return false;">
                <textarea placeholder="Your question" required></textarea>
                <button type="submit" class="btn btn-primary"><i class="fas fa-question"></i> Submit</button>
                <button type="button" class="btn btn-danger" onclick="closeModal('submitDoubt')"><i class="fas fa-times"></i> Cancel</button>
            </form>
        </div>
    </div>
    <script src="assets/js/scripts.js"></script>
    <script>
        function scanQRCode(event) {
            event.preventDefault();
            if (document.getElementById('location-dot').classList.contains('green')) {
                document.forms[0].submit();
            } else {
                alert('You must be inside campus to mark attendance');
            }
        }
        function faceRecognition() {
            if (document.getElementById('location-dot').classList.contains('green')) {
                fetch('python/face_recognition.php')
                    .then(response => response.text())
                    .then(data => alert(data));
            } else {
                alert('You must be inside campus to mark attendance');
            }
        }
        function submitDoubt(event) {
            event.preventDefault();
            const query = event.target[0].value;
            alert('Doubt submitted: ' + query);
        }
        function openModal(id) {
            document.getElementById(id).style.display = 'flex';
        }
        function closeModal(id) {
            document.getElementById(id).style.display = 'none';
        }
        checkLocation();
    </script>
</body>
</html>